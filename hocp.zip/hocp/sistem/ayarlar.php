<?php

/* OYGCP - OyunYoneticim Game Control Panel 
   Version: 1.0
   Dosya: "ayarlar.php"
   Yapımcı: OyunYoneticim Dev Team */

## - Veritabani - ##
date_default_timezone_set('Europe/Istanbul');
$oGCP['veritabani']['host'] = "localhost";
$oGCP['veritabani']['kadi'] = "oyuncnmd_herseyoyun";
$oGCP['veritabani']['sifre'] = "12341234Gbnn..";
$oGCP['veritabani']['vtadi'] = "oyuncnmd_herseyoyun";

## - Web Site Ayarlari * ##
$oGCP['web']['siteadres'] = "https://www.ocp.com.tr";
$oGCP['web']['panel'] = "HerseyOyun Game Control Panel -";
$oGCP['web']['version'] = "1.0.0";
$oGCP['web']['yapimci'] = "HOGCP";
$oGCP['web']['default-title'] = $oGCP['web']['panel']." ".$oGCP['web']['version'];

////// TS3 infoo
$ts_usrname = "serveradmin"; //QUERY KULLANİCİ
$ts_pass = "sifre.."; //QUERY ŞİFRE
$ts_host = "88.111.248.194";
$ts_qport = "10101"; // QUERY PORT



?>


