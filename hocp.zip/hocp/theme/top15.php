<?php include("ust.php"); ?>

<div class="row-fluid"><div class="widget widget-padding span12"><div class="widget-header">
<h5>&nbsp;&nbsp;&nbsp;&nbsp;Detaylı Top 15</h5>
<div class="widget-buttons"><a href="#" data-title="Collapse" data-collapsed="false" class="tip collapse"><i class="icon-chevron-up"></i></a>
</div></div>  
<div class="widget-body">
Top15 Kayıt sistemi belli bir oyuncu sayısına ulaştığında kendini otomatik resetler."Sıfırlama Sınırı" ise kaç kişi olucağını belirler.<br><br>
<table cellpadding="4"><tr><td>Sıfırlama Sınırı:</td><td><select><option>10.000 Oyuncu</option><option>11.000 Oyuncu</option><option>5.000 Oyuncu</option><option>6.000 Oyuncu</option><option>7.000 Oyuncu</option><option>8.000 Oyuncu</option><option>9.000 Oyuncu</option><option>12.000 Oyuncu</option><option>13.000 Oyuncu</option><option>14.000 Oyuncu</option><option>15.000 Oyuncu</option>
</td></tr><tr><td>Top15 Sıfırla</td><td><button class="btn btn-inverse">Uygula!</button></table><br>
<div align="center">
<table class="table table-striped" style="font-size: 12px;width: 50%;height 30%;">
<thead>
<tr>
<th  style="text-align:center">#</th>
<th style="text-align:center">Nick</th>
<th style="text-align:center">Olduren Sayisi</th>
<th style="text-align:center">Olen Sayisi</th>
<th style="text-align:center">Headshot</th>
</tr>
<tr>
<td style="text-align:center">1</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">2</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">3</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">4</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">5</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">6</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">7</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">8</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">9</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">10</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">11</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">12</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">13</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">14</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
<tr>
<td style="text-align:center">15</td>
<td>XrouRamein</td>
<td style="text-align:center">544</td>
<td style="text-align:center">78</td>
<td style="text-align:center">108</td>
</tr>
</table></div>
</div></div></div>

<?php include("alt.php"); ?>