﻿
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>404 / Sayfa Bulunamadı - OYGCP 1.0.1 </title>
</head>
<body>
  <center style="position: absolute; left: 66%; top: 40%; margin-left: -285px; margin-top: -190px;"><h2>Sayfa bulunamadı yada bu sayfayı görüntülemek için izniniz bulunmamaktadır.<br/><a href="http://panel.oyunyoneticim.com/Giris/">Anasayfa'ya DÃ¶n</a></h2></center>
  <img src="http://cdn.css-tricks.com/images/404.jpg" alt="Page Not Found (404)." style="position: absolute; left: 50%; top: 50%; margin-left: -285px; margin-top: -190px;">
</body>
</html>	