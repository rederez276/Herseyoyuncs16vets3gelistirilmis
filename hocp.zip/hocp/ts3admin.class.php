<?php
/**
 * TS3Admin Class
 * @version 1.1.0
 * @author TeamSpeak Systems GmbH
 * @url https://github.com/planetteamspeak/ts3admin-php
 * @license MIT
 */
class TS3Admin
{
    private $host;
    private $port;
    private $timeout;
    private $socket;
    private $connected = false;

    public function __construct($host, $port = 10011, $timeout = 10)
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
    }

    public function connect()
    {
        if ($this->connected) {
            return true;
        }

        $this->socket = fsockopen($this->host, $this->port, $errno, $errstr, $this->timeout);

        if ($this->socket) {
            $this->connected = true;
            $this->getResponse();
        } else {
            return false;
        }
    }

    public function login($username, $password)
    {
        $this->sendCommand("login $username $password");
        $response = $this->getResponse();

        return strpos($response, "error id=0") !== false;
    }

    public function sendCommand($command)
    {
        if (!$this->connected) {
            return false;
        }

        fwrite($this->socket, $command . "\n");
    }

    public function getResponse()
    {
        if (!$this->connected) {
            return false;
        }

        $response = "";
        while ($line = fgets($this->socket)) {
            $response .= $line;
            if (substr($line, 0, 1) == " ") {
                break;
            }
        }

        return $response;
    }

    public function setServerGroupByClientID($clientID, $groupID)
    {
        $this->sendCommand("servergroupaddclient sgid=$groupID cldbid=$clientID");
        return $this->getResponse();
    }

    public function disconnect()
    {
        $this->sendCommand("quit");
        fclose($this->socket);
        $this->connected = false;
    }
}
?>
