-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 16 Oca 2025, 21:16:19
-- Sunucu sürümü: 10.6.20-MariaDB
-- PHP Sürümü: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `oyuncnmd_herseyoyun`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_announcements`
--

CREATE TABLE `ogcp_announcements` (
  `AnnouncementID` int(11) NOT NULL,
  `AnnouncementTT` varchar(64) NOT NULL,
  `AnnouncementCont` text NOT NULL,
  `AnnouncementUserID` int(11) NOT NULL,
  `AnnouncementCreate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_announcements`
--

INSERT INTO `ogcp_announcements` (`AnnouncementID`, `AnnouncementTT`, `AnnouncementCont`, `AnnouncementUserID`, `AnnouncementCreate`) VALUES
(1, 'test', 'test', 1, '2013-12-03 06:06:06');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_files`
--

CREATE TABLE `ogcp_files` (
  `FileID` int(11) NOT NULL,
  `FileName` varchar(64) NOT NULL,
  `FilePath` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_files`
--

INSERT INTO `ogcp_files` (`FileID`, `FileName`, `FilePath`) VALUES
(2, 'Amx Mod X Ayarlari', '/addons/amxmodx/configs/amxx.cfg'),
(3, 'Admin Düzenle', '/addons/amxmodx/configs/users.ini'),
(4, 'Küfür Engelleme', '/addons/amxmodx/configs/reklamengel/kufur.ini'),
(5, 'Komut Yasaklama', '/addons/amxmodx/configs/KomutEngelleme/Musteri.ini'),
(6, 'Harita S?ralamas?', '/mapcycle.txt'),
(7, 'Harita Oylamas?', '/addons/amxmodx/configs/maps.ini'),
(8, 'Botlar', '/addons/amxmodx/configs/botisimleri.txt'),
(9, 'Yasakl? Tu?lar (Client Autoexec)', '/addons/amxmodx/configs/HO-YasakliTus.ini'),
(10, 'Eklenti Kur ve ya Kaldir', '/addons/amxmodx/configs/plugins.ini'),
(11, 'Say Mesajlar?', '/addons/amxmodx/configs/HO-SayMesajlari.ini'),
(12, 'Sol Reklamlar', '/addons/amxmodx/configs/reklam.txt');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_machines`
--

CREATE TABLE `ogcp_machines` (
  `MachID` int(11) NOT NULL,
  `MachIP` varchar(32) NOT NULL,
  `MachPort` int(11) NOT NULL,
  `MachUser` varchar(32) NOT NULL,
  `MachPass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_machines`
--

INSERT INTO `ogcp_machines` (`MachID`, `MachIP`, `MachPort`, `MachUser`, `MachPass`) VALUES
(2, '31.210.115.2', 1994, 'root', 'alper2014ramein'),
(3, '188.132.165.220', 22, 'root', 'ntXx7fJvRf'),
(4, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..'),
(5, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..'),
(6, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..'),
(7, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..'),
(8, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..'),
(9, '88.209.248.194', 10101, 'serveradmin', '12341234Gbnn..');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_packets`
--

CREATE TABLE `ogcp_packets` (
  `PacketID` int(11) NOT NULL,
  `PacketName` varchar(32) NOT NULL,
  `PacketStart` text NOT NULL,
  `PacketStop` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_packets`
--

INSERT INTO `ogcp_packets` (`PacketID`, `PacketName`, `PacketStart`, `PacketStop`) VALUES
(1, 'Public', 'screen -A -m -d -L -S Screen ./hlds_run -game cstrike -console -insecure -noipx -nojoy -debug -zone 4096 -heapsize 65535 +ip Ip +port Port +maxplayers Maxslot +map Map +exec server.cfg', 'screen -dr Screen -X quit');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_plugins`
--

CREATE TABLE `ogcp_plugins` (
  `PluginID` int(11) NOT NULL,
  `PluginName` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `PluginDesc` varchar(75) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `PluginFileName` varchar(64) NOT NULL,
  `PluginShow` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_plugins`
--

INSERT INTO `ogcp_plugins` (`PluginID`, `PluginName`, `PluginDesc`, `PluginFileName`, `PluginShow`) VALUES
(2, 'Bunny Ziplama', 'Seri seri tavşan biçiminde zıplamayı sağlar', 'HO-BunnyZiplama.amxx', 1),
(3, 'Adminlere Özel Şapka', 'Adminlere özel Şapka giydirmeyi sağlar', 'HO-AdminSapka.amxx', 1),
(4, 'Reset Skor', 'Skoru sıfırlamayı sağlar', 'HO-ResetSkor.amxx', 1),
(5, 'C4 Patlama Süresi', 'C4 hud mesajıyla patlama süresini sayar.[NOT: Pro Mod İçindir]', 'HO-C4PatlamaSuresi.amxx', 1),
(6, 'Bomba Düşmesi', 'Oyuncu ölünce bombanında yere düşmesini sağlar', 'HO-GrenadeDrop.amxx', 1),
(7, 'Bomba izi', 'Bombaların arkasından renkli iz çıkarmayı sağlar', 'HO-GrenadeTrail.amxx', 1),
(8, 'İzleyici listesi', 'Sağ üste izleyenleri görmenizi sağlar', 'HO-Speclist.amxx', 1),
(9, 'Hız Göstergesi', 'Ortada aşşağıda ne kadar hızda yürüdüğünü gösterir', 'HO-HizGostergesi.amxx', 1),
(10, 'Kanlı Ayak izi (25 HP Altı)', '25 Sağlıkdan az olduğunda oyuncunun yürümesinde kanlı ayak izi çıkartır', 'HO-KanliAyakizi.amxx', 1),
(11, 'Harita Süresi', 'Üstte Harita adı ve süresi yazan bir hud mesajı bulundurur', 'HO-MapName.amxx', 1),
(12, 'Sirtta Silah', 'Oyuncunun sırtında silah göstermeyi sağlar', 'HO-BackWeapons.amxx', 1),
(13, '3 Boyutlu Oynama', 'say\'dan \"/cam\" yazarak 3 Boyutlu ve ya Kuş bakışı oynamayı sağlar', 'HO-Kamera.amxx', 1),
(14, 'Tur Başı bilgiler', 'Her tur başlangıcında serverin kaçıncı tur,Harita, oyuncu sayısını gösterir', 'HO-RoundChatMessage.amxx', 1),
(15, 'Dürbünlü Deagle', 'Deagle\'ye sniper dürbünü eklemeyi sağlar', 'HO-DurbunluDeagle.amxx', 1),
(16, 'Ultimate Sesler', 'Oyunda öldürdüğünde erkek sesleri çıkmasını sağlar', 'HO-UltimateSesler.amxx', 1),
(17, 'Sol üst Admin listesi', 'Sol üstte \"Oyundaki adminler\" şeklinde online yetki çıkarır', 'HO-SUAL.amxx', 1),
(18, 'Oto Restart', 'Harita başlangıcında 30 saniye sayıp otomatik restart atmayı sağlar', 'HO-OtoRestart.amxx', 1),
(19, '100 Kalkan Başlangıç', 'El başı 100 Can\'ın yanına 100 Kalkan başlangıç yapmayı sağlar', 'HO-100Kalkan.amxx', 1),
(20, 'Trail (iz) Eklentisi', 'oyuncunun arkasından iz çıkarmayı sağlar', 'HO-Trail.amxx', 1),
(21, 'Kadın Ultimate Sesleri', 'Oyuncu ateş ettiğinde kadın ultimate sesleri çıkmasını sağlar', 'HO-KUltimateSesleri.amxx', 1),
(22, '+hook, +grap, +rope (Admine özel)', 'Genelde JailBreak Mod içindir.Ağ atmayı sağlar', 'HO-GHRA.amxx', 1),
(23, '+hook, +grap, +rope (Sadece CT Özel)', 'JailBreak Mod içindir.Ağ atmayı sağlar', 'HO-GHRCT.amxx', 1),
(24, 'Kar Yağdırma', 'Oyun içerisinde Kar Yağmasını Sağlar', 'HO-KarYagma.amxx', 1),
(25, 'Yağmur Yağdırma', 'Sunucuda yağmur yağmasını sağlar', 'HO-YagmurYagdirma.amxx', 1),
(26, 'Bedava Mermici Doldurucu (FreeAmmo)', 'Tur başı bedava mermi doldurmayı sağlar', 'HO-FreeAmmo.amxx', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_servers`
--

CREATE TABLE `ogcp_servers` (
  `ServerID` int(11) NOT NULL,
  `ServerMachID` int(11) NOT NULL,
  `ServerIP` varchar(32) NOT NULL,
  `ServerPort` int(11) NOT NULL,
  `ServerMaxPlayers` int(11) NOT NULL,
  `ServerMap` varchar(64) NOT NULL,
  `ServerPath` varchar(128) NOT NULL,
  `ServerPacket` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_servers`
--

INSERT INTO `ogcp_servers` (`ServerID`, `ServerMachID`, `ServerIP`, `ServerPort`, `ServerMaxPlayers`, `ServerMap`, `ServerPath`, `ServerPacket`) VALUES
(2, 2, '31.210.115.2', 27015, 32, 'de_dust2', '/home/cs2', 1),
(3, 2, '31.210.115.3', 27015, 32, 'de_dust2', '/home/cs3', 1),
(4, 2, '31.210.115.4', 27015, 32, 'de_dust2', '/home/cs4', 1),
(5, 2, '31.210.115.5', 27015, 32, 'de_dust2', '/home/cs5', 1),
(6, 2, '31.210.115.6', 27015, 32, 'deathrun_temple', '/home/cs6', 1),
(7, 2, '31.210.115.7', 27015, 32, 'deathrun_temple', '/home/cs7', 1),
(8, 2, '31.210.115.8', 27015, 32, 'de_dust2', '/home/cs8', 1),
(9, 2, '31.210.115.9', 27015, 32, 'de_dust2', '/home/cs9', 1),
(10, 2, '31.210.115.10', 27015, 32, 'de_dust2', '/home/cs10', 1),
(11, 2, '31.210.115.11', 27015, 32, 'fy_iceworld16', '/home/cs11', 1),
(12, 2, '31.210.115.12', 27015, 32, 'de_dust2', '/home/cs12', 1),
(13, 2, '31.210.115.13', 27015, 32, 'de_dust2', '/home/cs13', 1),
(14, 2, '31.210.115.14', 27015, 20, 'de_dust2', '/home/cs14', 1),
(15, 2, '31.210.115.15', 27015, 32, 'de_dust2', '/home/cs15', 1),
(16, 2, '31.210.115.16', 27015, 32, 'deathrun_temple', '/home/cs16', 1),
(17, 2, '31.210.115.17', 27015, 32, 'de_dust2', '/home/cs17', 1),
(18, 2, '31.210.115.18', 27015, 31, 'surf_ski_2', '/home/cs18', 1),
(19, 2, '31.210.115.19', 27015, 20, 'deathrun_temple', '/home/cs19', 1),
(20, 2, '31.210.115.20', 27015, 32, 'sea_dust2', '/home/cs20', 1),
(23, 2, '31.210.115.23', 27015, 22, 'deathrun_temple', '/home/cs23', 1),
(24, 2, '31.210.115.24', 27015, 22, 'deathrun_temple', '/home/cs24', 1),
(25, 2, '31.210.115.25', 27015, 32, 'zm_heal_dust2', '/home/cs25', 1),
(26, 2, '31.210.115.26', 27015, 22, 'surf_ski_2', '/home/cs26', 1),
(27, 2, '31.210.115.27', 27015, 32, 'de_dust2', '/home/cs27', 1),
(28, 2, '31.210.115.28', 27015, 22, 'de_dust2', '/home/cs28', 1),
(29, 2, '31.210.115.29', 27015, 32, 'deathrun_temple', '/home/cs29', 1),
(30, 2, '31.210.115.30', 27015, 24, 'hns_easycity', '/home/cs30', 1),
(31, 2, '31.210.115.21', 27015, 32, 'zm_dust2', '/home/cs21', 1),
(32, 2, '31.210.115.22', 27015, 20, 'de_dust2', '/home/cs22', 1),
(33, 3, '188.132.165.220', 27015, 32, 'de_dust2', '/root/csserver', 1),
(34, 3, '213.238.173.113', 27015, 32, 'de_dust2', '/root/csserver', 1),
(35, 3, '46.31.78.145', 27015, 32, 'de_dust2', '/root/csserver', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_ticketmessages`
--

CREATE TABLE `ogcp_ticketmessages` (
  `MessageID` int(11) NOT NULL,
  `MessageContent` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `MessageUserID` int(11) NOT NULL,
  `MessageTicketID` int(11) NOT NULL,
  `MessageCreateT` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_ticketmessages`
--

INSERT INTO `ogcp_ticketmessages` (`MessageID`, `MessageContent`, `MessageUserID`, `MessageTicketID`, `MessageCreateT`) VALUES
(244, 'evet öyle yaparsanız daha sağlıklı olur', 1, 83, '2014-03-11 15:16:41'),
(245, 'http://www.dosya.tc/server25/GtJtSm/ctmodels.rar.html Buyrun Linki Budur Herhangi bir t modelide siz eklerseniz sevinirim.', 76, 83, '2014-03-11 15:22:01'),
(246, 'Ayrica Spec Bot larini Yazdiktan sonra Kaydete tikliyorum hata veriyor ?', 76, 83, '2014-03-11 15:24:32'),
(247, 'İsteğiniz halledildi, Spec Bot yüklü olmadığı için kaydedemez', 1, 83, '2014-03-11 15:29:53'),
(248, 'Peki Spec Botunu Nasil yapicaz ?', 76, 83, '2014-03-11 15:30:24'),
(249, 'ayrica t de mic basmayi engelleye bilirmisiniz ?', 76, 83, '2014-03-11 15:30:56'),
(250, 'Şimdi düzenleyin\r\n', 1, 83, '2014-03-11 15:31:23'),
(251, 'T de mic basmayi Kapata bilirmisiniz ? ve Tam 30 Adet sXesiz Serveri otomatik favorilerinize eklemek icin F3 Tusuna  Basmaniz yeterli. yazisini Bulamadim Nerden Duzenliycem Ayrintili Sekilde Sekmeleri Yazarsaniz Sevinirim.', 76, 83, '2014-03-11 15:36:22'),
(252, 'Ayrica Spec de Sw Iplerimiz Gozukmuyor O reklam Engelleyiciyi Kaldirirsaniz Sevinirim Reklamlarimiz Gozukmuyor :)', 76, 83, '2014-03-11 15:39:19'),
(253, 'Malesef server güvenliği açısından önemli bir yeri vardır.DNS adresi yazarsanız daha iyi olur ileride bir sonraki versiyonunda spec botlarda sorun yaratmıcaktır\r\n', 1, 83, '2014-03-11 15:45:10'),
(254, 'tamam anlasildi birde bu market felan eskisi gibi olsun olurmu uste prison break sw ismi neyse o cikiyor ya ondan olursa sevinirim o nu geri yuklermisiniz.', 76, 83, '2014-03-11 15:46:12'),
(255, 'o şekilde güncelledim', 1, 83, '2014-03-11 15:51:55'),
(256, 'Menu Bu sekilde Olsun Ama pompa Testere Felan Olsun Anlata Bildimmi ?', 76, 83, '2014-03-11 15:54:33'),
(257, 'ayarladım', 1, 83, '2014-03-11 15:59:08'),
(258, 'Tama Cok Saolun Sizi Biraz Ugrastirdik Ama Emin Olun 1 2 Haftaya Bu Sw 1. olcak :) birde su tam 30 adet sxesiz yazi yerini bulamadim onu bana aciklarmisiniz tam olarak\r\n', 76, 83, '2014-03-11 16:02:33'),
(259, 'HO-Sunuculistesi.amxx içerisinde pawn kodlama olarak oluyor düzenleme gibi bir imkanı yok malesef\r\n', 1, 83, '2014-03-11 16:08:05'),
(260, 'Tamam Cok Saolun Gine bir Sorun Olursa Burdan Ticket ATicam tskr', 76, 83, '2014-03-11 16:08:57'),
(261, 'Ayrica Sunu Farkettim Smdi Kendime Jb Verdigimde TL verdigimde kimin kime nekadar verdigi gozukmuyor ayarlarsaniz sevinirim', 76, 83, '2014-03-11 16:19:19'),
(262, 'Herhangi bir  T  b ye basinca silah menusu cikiyor ve istedigi silahi ala biliyor acilen bi duzeltirmisiniz.', 76, 84, '2014-03-11 19:02:18'),
(263, 'Swye TeamSpeak3 Plugini Yuklermisiniz.. swde /ts3 Yazinca su Ts Ip\'e Girsin : 31.210.60.102:9987 Tesekkurler', 76, 85, '2014-03-11 19:33:26'),
(264, 'deathtun da herkez birbirine ates ede biliyor bunlari kapatirsaniz sevinirim', 76, 86, '2014-03-11 21:31:22'),
(265, 'cs12 cs21 gamemenulerı yapılsın gamemenulerde 2 serverında ısmı yazılsın.\r\npro servera autoconnect Eklenecek isteklerim bunlar.', 68, 87, '2014-03-11 22:32:26'),
(266, 'serverimiz cs7 deydi bir yetkiliyi swyi cs29 a tasidi cs7 dek alper yunuslar adli yoneticinin yaptigi butun pluginler ekledigi butun models pluginler silindi ve cs29 da panelde bir islem yaptigimda swde islemiyor swde admnlik yok panelde ne yaparsan yap swde islemiyor ve bir yetkili bu sorunlarin gece hal olacagini soyledi ayrica cs29 da da su sorunu yaparsaniz sevinirim.. jail breakda T \' b \' harfine basinca silah menusu cikiyor ve istedigi silahi ala biliyor buy 0 felan yaptik fakat serverde map degisince tekrar aktif oluyor onuda cozun bekliyorum.', 78, 88, '2014-03-12 00:35:17'),
(267, 'Ve ayrica www.hepoyuncu.com Sunucularda cs29 ipi hala Kiralik Gozukuyor.. Bu Sorunlari cok acilen lutfen halledin..', 78, 88, '2014-03-12 00:40:10'),
(268, 'KARDESIM DUN 29a TASIDINIZ SMDI 7 DE NOLUYOR BIRI BANA ACIKLASIN YA BUNE YAA ? PANELDEN BIRSEY YAPIYORUZ SWDE ISLEMIYOR SANKI O SWNIN PANELI DEGIL YAPILAN BUTUN EMELER BOSA GITTI ALPER YUNUSLAR GELSIN SIZ DIGERLERI ELLEMEYIN BISEYI ARTIK YETER LA..', 78, 1, '2014-03-12 09:35:42'),
(269, 'Merhabalar, HepOyuncu Yetkilileri Genelde Pro Mod harici modları arka plana atmaktadırlar.Sizi tekrar ön IP\'lere koyduk', 1, 1, '2014-03-12 13:27:45'),
(270, 'Kardesim Serverde Panelde Bir islem Yapiyorum alper swde islemiyo sanki baska swnin paneli gibiymis gibi\r\n', 78, 1, '2014-03-12 15:27:56'),
(271, 'panelde yaptigim reklamlar felan hersey gitti suan hic bise yok yani bi halledi ver acilen ya..', 78, 1, '2014-03-12 15:29:18'),
(272, '- uq_jumpstats_top.amxx v42, v38 hatası veriyor fixi şurada galiba https://forums.alliedmods.net/showthread.php?t=141586\r\n\r\n- kz_bugs_stats.amxx çalışıyor ama statsları top15e kaydetmiyor. plugin tagını [psychoGaming] ve enabled disabled yazılarını [psychoGaming] JB Stats acildi, kapandi. EB Stats açıldı, kapandi şeklinde yaparsan iyi olur.\r\n\r\n- csf kurulacak\r\n\r\nve son olarak  knife ve bomba modelleri değişecek. attıktan sonra mapste dahil olmak üzere faste atarsan iyi olur.\r\n\r\nhttp://cs.gamebanana.com/skins/105019\r\n\r\nmavi donduran bomba, yeşilde flash olsun\r\n\r\npıçak: http://cs.gamebanana.com/skins/105215\r\n\r\n\r\n\r\n\r\n', 41, 2, '2014-03-12 15:33:39'),
(273, '', 78, 1, '2014-03-12 17:08:55'),
(274, 'servere bir kere girip ciktiktan sonra sol tarafta sw ismi ne sw ipi yazsin o reklami koya bilirmisiniz.. ? ', 78, 3, '2014-03-12 18:47:14'),
(275, 'Attığım bildirim bu Orhun : -Zombie Canları Hepsi 200 sadece Hulk 225 olursa sevinirim. -Back ground veya Gamemenu bize özel olursa sevinirim. -amx_cvar mp_roundtime 3 olabilir. -Server dili sabit Türkçe. -El sonu lazerler her seferinde kalkmıyor ilginç. -El feneri açılmıyor server da fark ettim de , renkli güzel olanlarından varsa eklenebilir. -Oyuncunun üzerine tıkladığın da isim göstermiyor. \r\nAdmin yazınca gözüksün.', 70, 4, '2014-03-15 15:29:45'),
(276, 'Merhabalar Burakhan Bey, istekleriniz doğrultusunda sunucunuzda değişiklikler yapılmıştır, istekleriniz halli olmuştur, saygılarımızla..', 1, 2, '2014-03-18 14:05:27'),
(277, 'asdasd', 2, 5, '2025-01-14 18:03:27'),
(278, 'xxx', 2, 5, '2025-01-14 18:05:19'),
(279, 'zzzzzz', 2, 6, '2025-01-14 18:05:28'),
(280, 'zzzzzzz', 2, 6, '2025-01-14 18:05:35'),
(281, 'aa', 1, 6, '2025-01-14 18:08:23'),
(282, 'aa', 1, 5, '2025-01-14 18:08:35'),
(283, 'cxbvcvnbvcncv', 89, 7, '2025-01-16 20:58:24'),
(284, 'cxvxcvxcv', 89, 7, '2025-01-16 20:58:36');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_tickets`
--

CREATE TABLE `ogcp_tickets` (
  `TicketID` int(11) NOT NULL,
  `TicketUserID` int(11) NOT NULL,
  `TicketTitle` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `TicketMessageID` int(11) NOT NULL,
  `TicketStatus` int(11) NOT NULL DEFAULT 0,
  `TicketPriority` int(11) NOT NULL,
  `TicketCreateTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_tickets`
--

INSERT INTO `ogcp_tickets` (`TicketID`, `TicketUserID`, `TicketTitle`, `TicketMessageID`, `TicketStatus`, `TicketPriority`, `TicketCreateTime`) VALUES
(2, 41, 'Plugin', 0, 2, 3, '2014-03-12 15:33:39'),
(4, 70, 'Mod', 0, 0, 3, '2014-03-15 15:29:45'),
(5, 2, 'asdasd', 0, 3, 1, '2025-01-14 18:03:27'),
(6, 2, 'zzzzz', 0, 3, 1, '2025-01-14 18:05:28'),
(7, 89, 'cxbvcvnbvcncv', 0, 4, 1, '2025-01-16 20:58:24');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_users`
--

CREATE TABLE `ogcp_users` (
  `UserID` int(11) NOT NULL,
  `UserEmail` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci NOT NULL,
  `UserPassword` varchar(64) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserEmail2` varchar(128) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserPrefix` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_turkish_ci NOT NULL,
  `UserComment` text CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserName` varchar(64) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserCity` varchar(16) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserAddress` text CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserTelephone` varchar(24) CHARACTER SET latin5 COLLATE latin5_turkish_ci NOT NULL,
  `UserGroup` int(11) NOT NULL DEFAULT 0,
  `UserLastLogin` int(11) NOT NULL DEFAULT 0,
  `UserLastLogin2` int(11) NOT NULL DEFAULT 0,
  `ShowMachine` int(11) NOT NULL DEFAULT 0,
  `ShowServers` int(11) NOT NULL DEFAULT 0,
  `ShowUsers` int(11) NOT NULL DEFAULT 0,
  `ShowAnnouncements` int(11) NOT NULL DEFAULT 0,
  `ShowTickets` int(11) NOT NULL DEFAULT 0,
  `ShowPlugins` int(11) NOT NULL DEFAULT 0,
  `ShowFiles` int(11) NOT NULL DEFAULT 0,
  `UserCreateTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_users`
--

INSERT INTO `ogcp_users` (`UserID`, `UserEmail`, `UserPassword`, `UserEmail2`, `UserPrefix`, `UserComment`, `UserName`, `UserCity`, `UserAddress`, `UserTelephone`, `UserGroup`, `UserLastLogin`, `UserLastLogin2`, `ShowMachine`, `ShowServers`, `ShowUsers`, `ShowAnnouncements`, `ShowTickets`, `ShowPlugins`, `ShowFiles`, `UserCreateTime`) VALUES
(0, 'Sistem', 'Sistem', 'Sistem', '', 'Sistem', 'Sistem', 'Sistem', 'Sistem', 'Sistem', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2013-12-03 17:50:25'),
(1, 'Admin', '2f0d6731d780a641ee013b5087045a83', 'Admin', 'Alt Yapı Yetkilisi / Firma Sahibi', '', 'Alper YUNUSLAR', 'Admin', 'Admin', 'Admin', 3, 1737061374, 1737060960, 1, 1, 1, 1, 1, 1, 1, '0000-00-00 00:00:00'),
(2, 'test', '2f0d6731d780a641ee013b5087045a83', 'teste', '', 'test', 'test', 'teste', 'test', 'test', 1, 1736886157, 1736884299, 0, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(9, 'Lkalke28', '0a9e0b4270cbf1c8c3f98937ab7da7b8', '-', '', '-', 'Samet Kurtuluş', '-', '-', '-', 1, 1395957915, 1395864745, 0, 0, 0, 0, 0, 0, 0, '2013-12-08 00:23:12'),
(32, 'rrr', '1dc132e9b984eddacb5ba1224debbed5', 'mustafa_enes_11@hotmail.com', '', 'AKIYOR HANİ', 'M.E.A', 'Kocaeli', 'İzmit', '0539 934 42 11', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2014-01-04 18:41:09'),
(33, 'cavalry', '8bf19f292e7db50ede0a83dd27ecf886', 'satis@hepoyuncu.com', '', '-', 'Alper Yunuslar', '-', '-', '-', 1, 1388899395, 1388899055, 0, 0, 0, 0, 0, 0, 0, '2014-01-05 05:17:19'),
(36, 'mcsarena', '7c352031a10b2652ec3e6a0650bfc2df', 'Basturanberk@hotmail.com', '', '-', 'Berk Basturan', 'New York', '-', '-', 1, 1392024626, 1391936189, 0, 0, 0, 0, 0, 0, 0, '2014-01-07 07:15:44'),
(38, 'wanted', '8e7d79d96144cbbb642202c15398f164', 'naytwolf@windowslive.com', '', '-', 'Mehmet Fırat', '-', '-', '-', 1, 1396018490, 1396004755, 0, 0, 0, 0, 0, 0, 0, '2014-01-12 10:33:09'),
(39, 'LiveBomB', '1619b771fa2983ec31ccb57e6458ff87', 'qreat.yoneticiler@hotmail.com', '', 'Sponsor', 'Berkant Adım', 'İstanbul', '-', '0537 937 88 81', 1, 1396022675, 1396019883, 0, 0, 0, 0, 0, 0, 0, '2014-01-14 02:27:34'),
(41, 'psych0gaming', '0448bc76f47253946774dd9f44a4a435', '-', '', '-', 'Burakhan Yıldırım', '--', '-', '-', 1, 1395948249, 1395869942, 0, 0, 0, 0, 0, 0, 0, '2014-01-26 20:13:38'),
(44, 'serker123', '70aa9da0e6eada8166392bea0f4e95b3', 'q_kb_kb@hotmail.com', '', '-', 'Kerimcan zengin', 'İstanbul', '-', '05543797836', 1, 1394996308, 1394324353, 0, 0, 0, 0, 0, 0, 0, '2014-01-28 23:54:12'),
(46, 'BerkanN', '5ad3a8562d19735ffd3bb4f1c1ad6cf9', 'by3175@outlook.com', '', '-', 'Berkan ÜÇGÜL', '-', '-', '05310230135', 1, 1393788460, 1393788446, 0, 0, 0, 0, 0, 0, 0, '2014-01-31 19:22:19'),
(52, 'cs15', '3285e0713649c0af924911377cec73b1', '-', '', '-', 'Mazlum Yasak', '-', '-', '-', 1, 1394741310, 1394738245, 0, 0, 0, 0, 0, 0, 0, '2014-02-08 05:08:18'),
(57, 'Psycho07Clan', 'c81c9b22a662da0fc31b4a8d7474012c', 'Psycho@HepOyuncu.COM', '', '-', 'Psycho Gaming', '-', '-', '-', 1, 1394386655, 1394386229, 0, 0, 0, 0, 0, 0, 0, '2014-02-13 03:54:27'),
(59, 'cs26', '917bdc24ef3b251cc2b40be5aad4659a', 'Kaan_Akcora_34', '', '-', 'Kaan Akcora', 'Hannover', '-', '+4915734509848', 1, 1393878819, 1393540291, 0, 0, 0, 0, 0, 0, 0, '2014-02-16 16:25:21'),
(61, 'cikssy13', 'd91c26bc7d90c775a75c03dd5bc3c57d', 'https://www.facebook.com/cikssy', '', 'martın 4 ünde 80 tl ödenecek', 'harun batıt', 'bitlis', 'merkez', '05546627850', 1, 1393442686, 1393271913, 0, 0, 0, 0, 0, 0, 0, '2014-02-18 21:25:38'),
(62, 'istanbulue', 'c1e036b059b10e27884a67c38ea98512', 'jail_salih@hotmail.com', '', '-', 'Salih El', '-', '-', '05318958290', 1, 1395150189, 1395092438, 0, 0, 0, 0, 0, 0, 0, '2014-02-21 16:14:57'),
(68, 'naber', '0b97fa72aa5b781e8babb50207aa2b0a', 'neverbackdowncs', '', 'yok', 'musa kurtuluş', 'bursa', 'merkez', 'yok', 1, 1395702293, 1395676294, 0, 0, 0, 0, 0, 0, 0, '2014-02-28 20:16:41'),
(70, 'cs20', '3d18d7ad4013705b8878ec5f61a9ee16', '-', '', '-', 'Çağlar Fırat', '-', '-', '0544 742 34 24', 1, 1395345800, 1395166484, 0, 0, 0, 0, 0, 0, 0, '2014-03-02 04:24:07'),
(73, 'efegultekin', '8e0b287367992404535458f618186d44', '-', '', '-', 'Efe Gültekin', 'Angara', '-', '-', 1, 1395966132, 1395245742, 0, 0, 0, 0, 0, 0, 0, '2014-03-09 14:48:26'),
(75, 'a1907f', '953d229efe8804c966096cdb83214aa6', 'aytugfidan78@hotmail.com', '', '80 TL ödemesi var 15.03.2014', 'Aytuğ Fidan', 'İstanbul ', 'şişli', '05393432302	', 1, 1395853588, 1395774915, 0, 0, 0, 0, 0, 0, 0, '2014-03-10 18:12:36'),
(79, 'revenge', 'dca080a60b5c5d282f4fb2491cbd2570', 'FaLc0n_Tr@hotmail.com', '', '-', 'Selim VURANLAR', 'Bursa', '-', '-', 1, 1396016161, 1396015296, 0, 0, 0, 0, 0, 0, 0, '2014-03-12 16:43:16'),
(80, 'eray', '0e895b338ff1fc189f5feaed388e8b6b', 'amd.gaming@hotmail.com', '', '-', 'Eray Anuk', '-', '-', '-', 1, 1396009161, 1395865956, 0, 0, 0, 0, 0, 0, 0, '2014-03-18 15:41:24'),
(82, 'osmanulker', '8316b0d63978c2367c632c41c3acf83b', 'satis2@hepoyuncu.com', 'Team Speak 3 Yetkilisi', '-', 'Osman ÜLKER', '-', '-', '-', 2, 1395933785, 1395771035, 0, 1, 1, 0, 1, 0, 0, '2014-03-22 20:29:06'),
(83, 'MUHO', 'b8b9a1e0bd44daee5e1aae96699e5354', 'mertefe_36@hotmail.com.tr', '', '-', 'Mert Efe Yılmaz', 'Muğla', '-', '05457168136', 1, 1395950261, 1395689679, 0, 0, 0, 0, 0, 0, 0, '2014-03-24 18:29:43'),
(84, 'admin2', '486e27c651f400f22a3c37eb2fe26912', 'satis2@hepoyuncu.com', 'Yetkili Yönetici', '-', 'Selim Vuranlar', 'Bursa', '-', '-', 3, 1395948595, 1395877667, 1, 1, 1, 1, 1, 1, 1, '2014-03-26 18:24:14'),
(85, 'xxlesfos', 'db77ed7d0ebcf7b8e5ba5a334891d49d', 'bekoshe@gmail.com', '', '-', 'Yunus Özbek', '-', '-', '05301785214', 1, 1396004648, 1395956770, 0, 0, 0, 0, 0, 0, 0, '2014-03-26 18:30:39'),
(86, 'OrhunTOSUN', '920090bb526cf8cacb6f187ada4e7928', 'orhun@hepoyuncu.com', 'Teknik Destek Görevlisi', '-', 'Orhun TOSUN', 'Ankara', '-', '-', 2, 0, 0, 0, 1, 1, 0, 1, 0, 0, '2014-03-27 14:40:27'),
(87, 'alperozn', '9c845f8d36323ca0334f9a4ba1667e90', 'alperozn35@hotmail.com', '', '', 'Alper Özen', 'İstanbul', 'Bağcılar', '05352620810', 1, 1396018204, 1396018172, 0, 0, 0, 0, 0, 0, 0, '2014-03-27 18:24:08'),
(88, 'info@oyunculideri.com.tr', '91d3981ffcd6aff6e0fc5500585898e8', 'info@oyunculideri.com.tr', '', 'yok', 'cs1 cs1', 'yok', 'yok', 'yok', 1, 1736485406, 1736485373, 0, 0, 0, 0, 0, 0, 0, '2025-01-10 05:01:49'),
(89, 'info222@oyunculideri.com.tr', '91d3981ffcd6aff6e0fc5500585898e8', 'info222@oyunculideri.com.tr', '', '', 'cs2 cs2', 'cs2', 'cs2', '32q5235235', 1, 1737061400, 1737061095, 0, 0, 0, 0, 0, 0, 0, '2025-01-10 05:06:58');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogcp_userservers`
--

CREATE TABLE `ogcp_userservers` (
  `UserServerID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ServerID` int(11) NOT NULL,
  `UserServerStatus` int(11) NOT NULL DEFAULT 0,
  `ServerFTPCon` int(11) NOT NULL DEFAULT 0,
  `ServerPluginCon` int(11) NOT NULL DEFAULT 0,
  `UserServerPrice` int(11) NOT NULL,
  `UserServerPriceTime` int(11) NOT NULL,
  `UserServerBank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `ogcp_userservers`
--

INSERT INTO `ogcp_userservers` (`UserServerID`, `UserID`, `ServerID`, `UserServerStatus`, `ServerFTPCon`, `ServerPluginCon`, `UserServerPrice`, `UserServerPriceTime`, `UserServerBank`) VALUES
(11, 9, 25, 1, 1, 1, 0, 1420071827, 1),
(36, 32, 30, 1, 1, 1, 0, 67679, 5),
(37, 33, 25, 1, 1, 1, 0, 1420089450, 1),
(40, 36, 5, 1, 1, 1, 30, 1396824230, 2),
(42, 38, 25, 1, 1, 1, 0, 1420108417, 1),
(43, 39, 6, 1, 0, 1, 0, 1397481988, 1),
(46, 41, 30, 1, 0, 1, 0, 1420143228, 1),
(51, 46, 27, 1, 1, 1, 30, 1393704548, 1),
(64, 57, 13, 1, 1, 1, 40, 1394942811, 5),
(65, 59, 26, 1, 1, 1, 0, 1395073581, 0),
(70, 62, 16, 1, 1, 1, 30, 1395418517, 4),
(77, 70, 20, 1, 1, 1, 0, 1401679496, 0),
(86, 73, 2, 1, 0, 1, 0, 1741531734, 5),
(90, 75, 17, 1, 1, 1, 120, 1397150020, 4),
(98, 79, 8, 1, 1, 1, 0, 1420124604, 1),
(99, 79, 10, 1, 1, 1, 0, 1420124645, 0),
(100, 80, 2, 1, 1, 1, 0, 1420126895, 0),
(101, 80, 9, 1, 1, 1, 0, 1420126914, 1),
(102, 83, 4, 1, 1, 1, 0, 1420137052, 0),
(103, 85, 11, 1, 1, 1, 30, 1398533840, 3),
(104, 87, 7, 1, 1, 1, 0, 1420136657, 0),
(105, 89, 33, 1, 1, 1, 0, 1852318601, 1),
(106, 89, 35, 1, 1, 1, 0, 1852318612, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `servers`
--

CREATE TABLE `servers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slots` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `panelUserID` int(11) NOT NULL DEFAULT 0,
  `panelUcret` int(11) NOT NULL DEFAULT 0,
  `panelSonSure` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `servers`
--

INSERT INTO `servers` (`id`, `name`, `slots`, `port`, `username`, `panelUserID`, `panelUcret`, `panelSonSure`) VALUES
(0, '88.209.248.194_9988', '32', '9988', '89_9988', 89, 11, 1820610000);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yedekler`
--

CREATE TABLE `yedekler` (
  `ID` int(11) UNSIGNED NOT NULL,
  `ServerID` int(11) NOT NULL DEFAULT 0,
  `YEDEKADI` varchar(255) NOT NULL DEFAULT '',
  `YEDEKACIKLAMASI` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `ogcp_announcements`
--
ALTER TABLE `ogcp_announcements`
  ADD PRIMARY KEY (`AnnouncementID`);

--
-- Tablo için indeksler `ogcp_files`
--
ALTER TABLE `ogcp_files`
  ADD PRIMARY KEY (`FileID`);

--
-- Tablo için indeksler `ogcp_machines`
--
ALTER TABLE `ogcp_machines`
  ADD PRIMARY KEY (`MachID`);

--
-- Tablo için indeksler `ogcp_packets`
--
ALTER TABLE `ogcp_packets`
  ADD PRIMARY KEY (`PacketID`);

--
-- Tablo için indeksler `ogcp_plugins`
--
ALTER TABLE `ogcp_plugins`
  ADD PRIMARY KEY (`PluginID`);

--
-- Tablo için indeksler `ogcp_servers`
--
ALTER TABLE `ogcp_servers`
  ADD PRIMARY KEY (`ServerID`);

--
-- Tablo için indeksler `ogcp_ticketmessages`
--
ALTER TABLE `ogcp_ticketmessages`
  ADD PRIMARY KEY (`MessageID`);

--
-- Tablo için indeksler `ogcp_tickets`
--
ALTER TABLE `ogcp_tickets`
  ADD PRIMARY KEY (`TicketID`);

--
-- Tablo için indeksler `ogcp_users`
--
ALTER TABLE `ogcp_users`
  ADD PRIMARY KEY (`UserID`);

--
-- Tablo için indeksler `ogcp_userservers`
--
ALTER TABLE `ogcp_userservers`
  ADD PRIMARY KEY (`UserServerID`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_announcements`
--
ALTER TABLE `ogcp_announcements`
  MODIFY `AnnouncementID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_files`
--
ALTER TABLE `ogcp_files`
  MODIFY `FileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_machines`
--
ALTER TABLE `ogcp_machines`
  MODIFY `MachID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_packets`
--
ALTER TABLE `ogcp_packets`
  MODIFY `PacketID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_plugins`
--
ALTER TABLE `ogcp_plugins`
  MODIFY `PluginID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_servers`
--
ALTER TABLE `ogcp_servers`
  MODIFY `ServerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_ticketmessages`
--
ALTER TABLE `ogcp_ticketmessages`
  MODIFY `MessageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=285;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_tickets`
--
ALTER TABLE `ogcp_tickets`
  MODIFY `TicketID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_users`
--
ALTER TABLE `ogcp_users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- Tablo için AUTO_INCREMENT değeri `ogcp_userservers`
--
ALTER TABLE `ogcp_userservers`
  MODIFY `UserServerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
