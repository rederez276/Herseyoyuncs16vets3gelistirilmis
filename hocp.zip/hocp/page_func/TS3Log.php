<?php
	$echo = 0;
	if( !isset($_SESSION['auth']) ) {
		$page->GoLocation($page->CreatePageLink('Sunucu_Sec'));
	} else {
		$echo = 1;
	}
?>