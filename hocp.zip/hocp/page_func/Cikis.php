<?php 
	LogoutUser();
	$page->GoLocation($page->CreatePageLink("Giris"));
?>