<?php
	if( isset($_POST["ogcp_addmach"]) ) {
		if(@$_POST["mach_ip"] != "" || (int)@$_POST["mach_port"] != 0 || @$_POST["mach_kadi"] != "" || @$_POST["mach_pass"] != "") {
			if(Adm_AddMachine($_POST["mach_ip"],$_POST["mach_port"],$_POST["mach_kadi"],$_POST["mach_pass"])) {
				echo "Makine Eklendi!";
			} else {
				echo "Makine eklenemedi!";
			}
		}
	}
?>
<?php
if (isset($_POST["ogcp_addmach"])) {
    if (@$_POST["mach_ip"] != "" || (int)@$_POST["mach_port"] != 0 || @$_POST["mach_kadi"] != "" || @$_POST["mach_pass"] != "") {
        // Example TS3Admin connection
        require_once("ts3admin.class.php");

        $ts3 = new TS3Admin($_POST["mach_ip"], $_POST["mach_port"]);

        if ($ts3->connect()) {
            // Assuming login credentials are for the TeamSpeak server
            if ($ts3->login($_POST["mach_kadi"], $_POST["mach_pass"])) {
                // Successfully connected to the server
                // Add machine to the database or do whatever is needed for your application
                if (Adm_AddMachine($_POST["mach_ip"], $_POST["mach_port"], $_POST["mach_kadi"], $_POST["mach_pass"])) {
                    echo "Makine Eklendi!";
                } else {
                    echo "Makine eklenemedi!";
                }
            } else {
                echo "Giriş başarısız!";
            }
        } else {
            echo "TeamSpeak sunucusuna bağlanılamadı!";
        }
    }
}
?>
