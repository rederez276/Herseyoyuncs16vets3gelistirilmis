<?php 
	$duyurular = GetAnnouncementsList();
?>