<?php
	$ts3array = array();
	$edit = false;
	require_once("tsv5/libraries/TeamSpeak3/TeamSpeak3.php");
	require_once("sistem/ayarlar.php");
	$sql_query = "Select * From servers LEFT JOIN ogcp_users ON UserID = panelUserID where 1";
	$sql_query = $baglan->query($sql_query);
	if( $sql_query->rowCount() > 0 ) {
		while($fetch = $sql_query->fetch(PDO::FETCH_ASSOC)) {
    	    	$ts3array[$fetch['id']] = $fetch;
    	}
    }
    try {
	    if(@$_GET["Islem"] == "Sil" && (int)@$_GET["ID"] != 0 && isset($ts3array[(int)@$_GET["ID"]]) ) {
			$del_query = $baglan->prepare("DELETE FROM servers WHERE id=".intval($_GET["ID"]));
			$del_query->execute();
			if($del_query->rowCount() > 0) {
				$ts3_serv = TeamSpeak3::factory("serverquery://$usrname:$pass@$host:$qport/?server_port=".$ts3array[(int)$_GET['ID']]['port']);
				$ts3_serv->stop();
				$ts3_serv->delete();
				unset($ts3array[(int)$_GET["ID"]]);
				echo "TS3 Silindi!";
			} else {
				echo "TS3 Silinemedi!";
			}
		} elseif( isset($_GET['Duzenle']) && isset($ts3array[$_GET['Duzenle']]) ) {
			$kullanicilar = Adm_GetTSUserList();
			$ts3server = $ts3array[$_GET['Duzenle']];
			$edit = true;
			if(isset($_POST["ogcp_editts3"])) {
				if(@$_POST["mach_ip"] == "")	$_POST["mach_ip"] = $machine["MachIP"];
				if((int)@$_POST["ts3port"] <= 0 || (int)@$_POST["ts3port"] > 65535)	$_POST["ts3port"] = (int)$ts3server["port"];
				if((int)@$_POST["ts3slot"] <= 0) $_POST["ts3slot"] = (int)$ts3server["slots"];
				if((int)@$_POST["ts3ucret"] < 0) $_POST["ts3ucret"] = (int)$ts3server["panelUcret"];
				if(strtotime(@$_POST["ts3tarih"]) < 0) $_POST["ts3tarih"] = (int)$ts3server["panelSonSure"];
				else $_POST["ts3tarih"] = strtotime($_POST["ts3tarih"]);
				if( !isset($kullanicilar[$_POST['ts3user']]) ) $_POST["ts3user"] = $ts3server['panelUserID'];
				$ts3_serv = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$ts3server['port']);
				$ts3_serv->virtualserver_port = (int)$_POST['ts3port'];
				$ts3_serv->virtualserver_maxclients = (int)$_POST['ts3slot'];
				$del_query = $$baglan->prepare("UPDATE servers SET port = ".(int)$_POST['ts3port'].", slots = ".(int)$_POST['ts3slot'].", panelUserID = ".$_POST['ts3user'].", username = '".$_POST['ts3user']."_".(int)$_POST['ts3port']."', panelUcret = ".$_POST['ts3ucret'].", panelSonSure = ".(int)$_POST['ts3tarih']." WHERE id=".intval($_GET["Duzenle"]));
				$del_query->execute();

				$page->GoLocation($page->CreatePageLink($cur_page,'Duzenle='.$_GET['Duzenle']));
			}
		}
	} catch( Exception $e ) {
		echo 'Hata: '. $e->getMessage();
	}
?>