<?php 

namespace App;

class Verify{
	private $cnx;

	public function __construct($cnx){
		$this->cnx = $cnx;
	}


	public function checkTS($username){
		$req = $this->cnx->prepare("SELECT * FROM servers WHERE username = :username");
		$req->execute(array('username' => $username));
		$check = $req->fetch();
		if(!empty($check['port'])){
			$_SESSION['flash']['danger'] = "Zaten Sunucunuz Var 1Den Fazla Sunucu Oluşturulmaz!";
			header('Location: index.php');
			exit();
		}
	}

	public function checkIndex($username){
		$req = $this->cnx->prepare("SELECT * FROM servers WHERE username = :username");
		$req->execute(array('username' => $username));
		$check = $req->fetch();
		if(empty($check['port'])){
			$_SESSION['flash']['warning'] = "Oluştur!";
			header('Location: create.php');
			exit();
		}
	}


}