<?php 
namespace App;

class Register{

	private $cnx;

	public function __construct($cnx){
		$this->cnx = $cnx;
	}

	public function check_pseudo($pseudo){
		 if (preg_match('/^[a-zA-Z0-9_]+$/', $pseudo) && strlen($pseudo) > 4 && strlen($pseudo) < 25) {
		 	$req = $this->cnx->prepare('SELECT id FROM users WHERE pseudo = :pseudo');
	        $req->execute(array("pseudo" => $pseudo));
	        $user = $req->fetch();
	        if($user){
	            $_SESSION['flash']['danger'] = "Kullanici Adi Sistemde Kullaniliyor!";
	        }else{
		    return $pseudo;
			}
		 } else {
		    $_SESSION['flash']['danger'] = "Lütfen 4 ila 25 arasında karakter giriniz!";
		 }

	}

	public function check_email($email){
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		    $req = $this->cnx->prepare('SELECT id FROM users WHERE email = :email');
	        $req->execute(array("email" => $email));
	        $user = $req->fetch();
	        if($user){
	            $_SESSION['flash']['danger'] = "Mailiniz Sistemde Kullaniliyor!";
	        }else{
		    return $email;
			}
		}else{
			$_SESSION['flash']['danger'] = "Yanlis Email Girdiniz!";
		}
	}

	public function check_password($pass1, $pass2){
		if(empty($pass1) || $pass1 != $pass2){
			$_SESSION['flash']['danger'] = "Lutfen Sifre Giriniz";
		}else{
			if(strlen($pass1) < 255){
				$password = password_hash($pass1, PASSWORD_BCRYPT);
				return $password;
			}else{
				$_SESSION['flash']['danger'] = "Sifreniz Maksimum 255 karakter olabilir!";
			}
		}
	}

	public function create_account($pseudo, $email, $password){
			$q = array('pseudo' => $pseudo, 'email' => $email, 'password' => $password);
			$req = $this->cnx->prepare("INSERT INTO users(pseudo, email, password) 
										VALUES (:pseudo, :email, :password)");
			$req->execute($q);
			$_SESSION['flash']['success'] = "Basariyla Olusturuldu! !";
	}


}