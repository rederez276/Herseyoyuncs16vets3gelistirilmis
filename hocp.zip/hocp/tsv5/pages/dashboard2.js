  'use strict';
$(document).ready(function() {

    //after fade animation has finished remove the class that caused it so it can be reused
    $('.update').on('webkitAnimationEnd oAnimationEnd msAnimationEnd animationend', function() {
        $('.anim').removeClass('anim');
    });

    function digclock() {
        var d = new Date()
        var t = d.toLocaleTimeString()

       /* document.getElementById("system-clock").innerHTML = t;*/
    }

    setInterval(function() {
        digclock()
    }, 1000);

    // Click handlers
    $(".sidebar-btn").on("click", function() {
        var $this = $(this);
        var action = $this.attr("data-action");
        var side = $this.attr("data-side");
        $(".sidebar." + side).trigger("sidebar:" + action);
        return false;
    });
    $(".closebtn").on("click", function() {
        $(".sidebar.right").css('right', '-350px');
    });
    $(".right-sidebar-panel").on("click", function() {
        return false;
    });
    /*Side-bar Menu Ends*/

    function setHeight() {
        var $window = $(window);
        var windowHeight = $(window).height();
        if ($window.width() >= 320) {
            $('.user-list').parent().parent().css('min-height', windowHeight);
            $('.user-list').parent().parent().css('right', -300);
        }
    };
    setHeight();

    $(window).on('load',function() {
        setHeight();
    });
});

$('.to-do-list input[type=checkbox]').click(function(){
        if($(this).prop('checked'))
            $(this).parent().addClass('done-task');
        else
            $(this).parent().removeClass('done-task');
    });