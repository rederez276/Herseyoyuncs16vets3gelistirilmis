  'use strict';
 $(document).ready(function() {
        $('#e-product-list').DataTable({
            "paging":   true,
            "ordering": false,
            "bLengthChange": false,
            "info":     false,
            "searching": false
        });
    } );