  'use strict';
$(document).ready(function(){
		$('#lightgallery').lightGallery();
		$('#lightgallery1').lightGallery();
	});