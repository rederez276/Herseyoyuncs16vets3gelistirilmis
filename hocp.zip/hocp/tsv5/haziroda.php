<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['kick'])) {
		
		$reason = $_POST['reason'];
		$nick = $_POST['client'];
		
		$ts3_VirtualServer->clientGetByName($nick)->kick(TeamSpeak3::KICK_SERVER, $reason);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Görüntüke</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">


  <?php
		  if($_POST['jailbreak']){






// create a top-level channel and get its ID
$top_cid2 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer1]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));

$top_cid2 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer0]$nome_sala oғғιce",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));
 
 $top_cid3 = $ts3_VirtualServer->channelCreate(array( 
   'channel_name'           => "[*spacer2]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
   $top_cid4 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]┏╋━━━━━━◥◣◆◢◤━━━━━━╋┓",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
  
  ));
 
 $top_cid5 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]$nome_sala Aιleѕι",
  'channel_topic'          => "$nome_sala",
  'channel_power'  => "$random",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
 ));

 $top_cid6 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]ғв.coм/$nome_sala",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
$top_cid7 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]X X . X X X . X X X . X X X",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid8 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]Sιɴce 2009",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid9 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]┗╋━━━━━━◥◣◆◢◤━━━━━━╋┛",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid10 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer3]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid11 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]┏━━━━━━━━━",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid12 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] αdмinliк ғiуαтlαrι ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid13 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]кσмυтcυ ѕιѕтeмi ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid14 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]ileтişiм вilgileri ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid15 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] ѕerνer кυrαllαrι ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid16 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] ѕlσтlυк ѕιѕтємι ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]мαρ liѕтeѕi ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid18 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] cezαlı кişiler ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid19 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] genel çözüмler ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid20 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] уönєтiм єкiвiмiz ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid21 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer] ödeмe γönтeмleri ©",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid22 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]┗━━━━━━━━━",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid23 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer4]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid24 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]нer cυмαrтeѕι",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid25 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]20:00 dα тoplαɴтıмız vαrdır",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid26 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer5]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid27 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]( тσρlαnтı σdαѕı )",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid28 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer6]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid29 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]( welcoмe тo $nome_sala )",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid30 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer7]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid31 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]╔-● $nome_sala » clαn'α αlıм 1",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid32 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]╠-● $nome_sala » clαn'α αlıм 2",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid33 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]╚-● $nome_sala » yoĸlαмα odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid34 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer8]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid35 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » мαкαrα odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid36 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » ѕoнвeт odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid37 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » iѕуαη тєαм odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid38 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » cт odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid39 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » кσмυт din. odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid40 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » мüziк din. odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid41 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » eтĸιɴlιĸ odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid42 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » вαуαη odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid43 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » мαpper odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid44 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]● $nome_sala » özel odα",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid45 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer9]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid46 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]α ғ к odαѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid47 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer10]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));



}
?>		
    <?php
		  if($_POST['metin2']){




$top_cid1 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer21]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));

$top_cid2 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]بِسْــــــــــــــــــمِ اﷲِالر",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));
 
 $top_cid3 = $ts3_VirtualServer->channelCreate(array( 
   'channel_name'           => "[*spacer22]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
   $top_cid4 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]۞  αdмιɴ odαѕı  ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
  
  ));
 
 $top_cid5 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]۞  уöɴєтιм  ۞",
  'channel_topic'          => "$nome_sala",
  'channel_power'  => "$random",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
 ));

$top_cid6 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]Powered By BeyazSunucu.CoM",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid7 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer23]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid8 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╔══════๑۩۞۩๑══════╗",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid9 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer][☾☆ α∂мιη ∂υуυяυℓαя ☾☆]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid10 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer][☾☆ тσρℓαηтı σ∂αѕı☾☆]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid11 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer][☾☆ αν¢ı σ∂αѕı ☾☆]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid12 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer][☾☆ кυяαℓℓαя ☾☆]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid13 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer][☾☆ ιℓєтιşιм ☾☆]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid14 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer0]╚═══๑۩۞۩๑═══╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid15 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer24]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid16 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]☆☞ ٠•●─═ ∂єѕтєк ═─●•٠ ☜☆",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer25]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid18 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╔/════๑ஜ۩۞۩ஜ๑════\╗)",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid19 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]● нσѕgєℓ∂ιηιz / ℓσвι ●",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid20 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╚\════๑ஜ۩۞۩ஜ๑════/╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid21 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer27]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid22 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]►►►►►►►►►►►►►◄◄◄◄◄◄◄◄◄◄◄◄◄◄",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid23 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]ıℓıℓı ♪♫ мüzιк σ∂αѕı ♪♫ ıℓıℓı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid24 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer2]►►►►►►►►►►►►►◄◄◄◄◄◄◄◄◄◄◄◄◄◄",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer28]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid25 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Toplantı Odası",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid26 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Yönetim Ekibi",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid27 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[[spacer]║ ● $nome_sala Sohbet Odası",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid28 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Sarı Bayrak",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid29 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Mavi Bayrak",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid30 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Kırmızı Bayrak",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid31 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala Ticaret Odası",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid32 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer]║ ● $nome_sala AFK Odası",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid33 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer9]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));



}
?>		
    <?php
		  if($_POST['takil']){



$top_cid1 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer0]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));

$top_cid2 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]$nome_sala",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));
 
$top_cid3 = $ts3_VirtualServer->channelCreate(array( 
   'channel_name'           => "[spacer1]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
$top_cid4 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer313]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
$top_cid5 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]Powered By BeyazSunucu.CoM",
  'channel_topic'          => "$nome_sala",
  'channel_power'  => "$random",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
 ));
$top_cid6 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer32]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid7 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Gamer House # 1",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid8 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Gamer House # 2",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid9 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Gamer House # 3",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid10 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Gamer House # 4",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid11 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Gamer House # 5",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid12 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Private Room # [Max 2]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid13 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Private Room # [Max 3]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid14 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Private Room # [Max 4]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid15 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Private Room # [Max 5]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid16 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[spacer35]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Müzik Botları [Botlar Çalışıyor]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid18 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Away From Keyboard",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid19 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer37]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid20 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]Özel Odalar",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid21 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer38]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid22 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Genel Toplantı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid23 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Genel Sohbet",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid24 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Yönetim",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid25 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer39]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid26 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]Küfür, Argo ve Hakaret Yasaktır",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid27 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid28 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "☩ Bilgilendirme Odaları ⬇️⬇️",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid29 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "☩ Steam Grubumuz",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid30 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "☩ Yetkiler Ne İşe Yarar ?",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid31 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "☩ Nasıl Özelden Mesaj Atarım ?",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid32 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "☩ Server Kurallarımız !",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid33 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer123]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid34 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "# Lobby",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid35 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "# 7 / 24 Live Music",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid36 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "# Oda Açtırma / Açıklamayı Okuyun",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid37 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "# Away From Keyboard",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid38 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer133]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid39 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] - 1.Bölge [0/5] -",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid40 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer134]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid41 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 1",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid42 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 2",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid43 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 3",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid44 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 4",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid45 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 5",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid47 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer135]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid48 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] - 2.Bölge [0/3] -",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid49 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 2.1",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid50 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 2.2",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid51 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "Kalıcı Oda 2.3",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid52 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer136]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid53 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]• Geçici Odalar •",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid54 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer137]___",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));


}
?>
    <?php
		  if($_POST['wolfteam']){


$top_cid1 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer1]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));

$top_cid2 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]بِسْــــــــــــــــــمِ اﷲِالر",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

  ));
 
 $top_cid3 = $ts3_VirtualServer->channelCreate(array( 
   'channel_name'           => "[*spacer0]",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
));
   $top_cid4 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]╔═════════════╗",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
  
  ));
 
 $top_cid5 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]вαşкαη oғғιce ╣",
  'channel_topic'          => "$nome_sala",
  'channel_power'  => "$random",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,
 ));

$top_cid6 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]вαşкαη уя∂ oғғιce ╣",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid7 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[rspacer]╚═════════════╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid8 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer1]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid9 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╔══════════════════════╗",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid10 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> уöηєтιм єкιвιмιz",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid11 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> уєткı ѕıѕтємı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid12 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> тσρℓαηтı σ∂αѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid13 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> ѕσнвєт σ∂αѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid14 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> σуυη σ∂αѕı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid15 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> кυяαℓℓαяıмız",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid16 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> кℓαη σуυηcυℓαяı",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> мαρ ℓιѕтєѕι",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid18 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╠> ι̇ℓєтιşιм",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid19 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "╚══════════════════════╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid20 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer61]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid21 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╔/═══════๑ஜ۩۞۩ஜ๑═══════\╗",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid22 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]  $nome_sala",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid23 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╚\═══════๑ஜ۩۞۩ஜ๑═══════/╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid24 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer75]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid17 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer1]▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid25 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]тω кσηтяσℓ σ∂αѕι Ι",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid26 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer2]▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid27 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]тω кσηтяσℓ σ∂αѕι ΙΙ",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid28 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer3]▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid29 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]тω кσηтяσℓ σ∂αѕι ΙΙΙ",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid30 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer4]▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃▃",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid31 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer6661]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid32 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╔═══════════๑۩۞۩๑══════════╗",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid34 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]★ H O Ş G E L D İ N İ Z ★",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid35 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]╚═══════════๑۩۞۩๑══════════╝",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid36 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer666771]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid37 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer21] ☆ ═════════ ☆ ══════════ ☆",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid38 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]★ кℓαη αℓıм σ∂αѕı ★",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid39 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer212] ☆ ═════════ ☆ ══════════ ☆",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid40 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]♥ мυzιк ~ σ∂αѕı ♥",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid41 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer213] ☆ ═════════ ☆ ══════════ ☆",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid42 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer6666771]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid43 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid44 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ klan Savaşı Bekleme Odası ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid45 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy3]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid46 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❶ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid47 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy4]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid48 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❷ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid49 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy5]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid50 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❸ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid51 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy6]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid52 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❹ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid53 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy7]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid54 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer]۞ кℓαη ѕαναşı σ∂αѕı ❺ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid55 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy8]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid56 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❻ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid57 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy9]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid58 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❼ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid59 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy10]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid60 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] ۞ кℓαη ѕαναşı σ∂αѕı ❽ ۞",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid61 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spaceruy11]_",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid62 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer66667791]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid62 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[cspacer] (A) ωαу (F) яσм (K) єувσαя∂",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));
$top_cid62 = $ts3_VirtualServer->channelCreate(array(
  'channel_name'           => "[*spacer66667d791]▨▤",
  'channel_topic'          => "$nome_sala",
  'channel_codec'          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  'channel_flag_permanent' => TRUE,

));

}
?>		














  <?php
		  if($_POST['knight']){


 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer0]...",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 





 $godanum20 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer] H O Ş G E L D İ N İ Z",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

    "CHANNEL_NEEDED_TALK_POWER" => "100",

  "channel_flag_default" => TRUE,	



)); 



 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer]...",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 









 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]=== [ KLAN ADI ] ===",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Yönetim",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Sohbet",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Toplanti",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan PK 1",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan PK 2",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan PK 3",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan AFK",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_needed_talk_power" => 999999,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $top_cid = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer1]...",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

}
?>			






<?php
		  if($_POST['genelodav3']){


 $godanum = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer894]___",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "channel_needed_join_power" => 100,

)); 



 $godanum1 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]╔══════════════════════╗",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 









 $godanum2 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]٠•●۞ уöηєтιм σ∂αѕı ۞●•٠",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 







 $godanum3 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]╚══════════════════════╝",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  







 $godanum4 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer89561989498cccccc8ca82221344]___",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 



  







 $godanum5 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "╔═════════════════════════════╗",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,

)); 

 

 

 

 

 

  







 $godanum6 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ уσηєтιм єкιвιмιz",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,

)); 

 

 

 

 

 

  







 $godanum7 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ кυяαℓℓαяıмız",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 

 

 

 

 

  







 $godanum8 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ dυyυrυlαr",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 

 

 

 

 

  







 $godanum9 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ вιℓgιℓєη∂ιямє",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 

 

 

 

 

  







 $godanum10 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ тσρℓαηтı σ∂αѕı",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 

 

 

 

 

  







 $godanum11 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "║•●۞ ιℓєтιѕιм",

  "channel_topic"          => "",

  "channel_description"          => " ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 



 

 

 

 

  







 $godanum12 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "╚═════════════════════════════╝",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,  

)); 

 

 

 

 

 

  

  







 $godanum13 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer89561989498cccccc882221344]___",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum14 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer8]↓",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum15 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer9]Ðєѕтєк – Kαyıт Yαpтırмα",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 





 $godanum16 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer10]Ðєѕтєк – Öηєяι̇ Şι̇кαуєт",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum17 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer12]↑",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum18 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacerxw13]___",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum19 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]╔────╬╬╬─────────╬╬╬───╗",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum20 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer] •●۞ H σ ş g є ℓ ∂ i η i z ۞●•",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

    "CHANNEL_NEEDED_TALK_POWER" => "100",

  "channel_flag_default" => TRUE,	



)); 

 

 

 



  







 $godanum21 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]╚────╬╬╬─────────╬╬╬───╝",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum22 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacerwxx13]___",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum23 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer7]╔══════════════════════╗",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum24 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]ѕσнвєт σ∂αѕı",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum25 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer4]╠══════════════════════╣",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum26 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]♫♫ мüzιк σ∂αѕı ♫♫",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum27 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer9]╚══════════════════════╝",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum28 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacerwxc13]___",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum29 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer36]▄",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum30 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer37]▬▬▬▬▬▬▬▬▬๑۩۞۩๑▬▬▬▬▬▬▬▬▬",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

  

  







 $godanum31 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer]► ☆ KLAN ADI ☆ ◄",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

  

  







 $godanum32 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[cspacer39]▬▬▬▬▬▬▬▬๑۩۞۩๑▬▬▬▬▬▬▬▬",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

 

 

 

 

 

 

  $godanum33 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Yönetim",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

  "total_clients_family" => 0,

  "channel_maxclients" => 0,

  "channel_maxfamilyclients" => -1,

  "total_clients" => 0,

));









  $godanum34 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Sohbet",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

));  

 

 

  

  

  $godanum35 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Toplanti",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 









  $godanum36 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan Maç",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 











  $godanum37 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "Klan AFK",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_needed_talk_power" => 999999,

  "channel_flag_permanent" => TRUE,

)); 







 $godanum38 = $ts3_VirtualServer->channelCreate(array(

  "channel_name"           => "[*spacer40]▄",

  "channel_topic"          => "",

  "channel_description"          => "  ",

  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,

  "channel_flag_permanent" => TRUE,

)); 

}
?>			





































	
<br><br>
<div class="panel panel-default">

  <div class="panel-heading"><center>Counter-Strike JailBreak Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['jailbreak'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >




										<center><img src="images/jail.png"><input type="submit" name="jailbreak" class="btn btn-info" value="Odayı Kur!" />
								</div>
							</form><br><br>
							
							<?php } ?>
													</div>
					</div>
					
				</div>
		</div>
		
	</div>


<div class="panel panel-default">

  <div class="panel-heading"><center>Metin 2 Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['metin2'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >


						
								<div class="box-footer">
									
									
									<center><img src="images/metin.png"><input type="submit" name="metin2" class="btn btn-info" value="Odayı Kur!" />
								</div>
							</form><br><br>
							
							<?php } ?>




													</div>
					</div>
					
				</div>
		</div>
		
	</div>






<div class="panel panel-default">

  <div class="panel-heading"><center>Oda Aç Takıl Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['takil'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >


						
								<div class="box-footer">
									
									
									<center><img src="images/takil.png"><input type="submit" name="takil" class="btn btn-info" value="Odayı Kur!" />
									</div>
							</form><br><br>
							
							<?php } ?>




													</div>
					</div>
					
				</div>
		</div>
		
	</div>






<div class="panel panel-default">

  <div class="panel-heading"><center>Genel Oda Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['genelodav3'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >


						
								<div class="box-footer">
									
									
									<center><img src="images/geneloda.jpg"><input type="submit" name="genelodav3" class="btn btn-info" value="Odayı Kur!" />
								</div>
							</form><br><br>
							
							<?php } ?>




													</div>
					</div>
					
				</div>
		</div>
		
	</div>




























<div class="panel panel-default">

  <div class="panel-heading"><center>Knight Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['knight'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >


						
								<div class="box-footer">
									
									
<center><img src="images/knightoda.jpg"><input type="submit" name="knight" class="btn btn-info" value="Odayı Kur!" />
								
									</div>
							</form><br><br>
							
							<?php } ?>




													</div>
					</div>
					
				</div>
		</div>
		
	</div>



<div class="panel panel-default">

  <div class="panel-heading"><center>Wolfteam Hazır Oda Kur</div></center>

<div class="panel panel-default">


  <div class="panel-body">
<form class="form-signin" method="POST">
            <header>
			</header>					
					<div class="box box-warning">
						<div class="box-header with-border">
							<h3 class="box-title"></h3>
						</div>
						<div class="box-body">
						<?php if(isset($_POST['wolfteam'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							<?php }else{?>
							
							<form role="form" method="post" >


						
								<div class="box-footer">
									
									
									<center><img src="images/wolfteam.png"><input type="submit" name="wolfteam" class="btn btn-info" value="Odayı Kur!" />
								</div>
							</form><br><br>
							
							<?php } ?>




													</div>
					</div>
					
				</div>
		</div>
		
	</div>














</div>
													</div>
					</div>
					
				</div>
		</div>
		
	</div>












</div>
													</div>
					</div>
					
				</div>
		</div>
		
	</div>



					
					
				</div>
		</div>
		</center>
		</center>
		</div>
		</label<select>
		</center>
		</div>
		</form>
		</b>
		</div>
		</div>
		</div></div>
		
	</div>
	</div>
	</body>
	</html>
	

										

					  