<?php 
session_start();
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'inc/ts.php';
require 'inc/db.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkTS($_SESSION['auth']['pseudo']);
  if(isset($_POST) && !empty($_POST['name']) && !empty($_POST['slots'])){
    $name = $_POST['name'];
    $slots = $_POST['slots'];

      if($slots > 35){
        $_SESSION['flash']['danger'] = "Max slots = 32";
        header('Location: create.php');
        exit();
      }elseif(!preg_match('/^[a-zA-Z0-9_]+$/', $name)){
        $_SESSION['flash']['danger'] = "Lütfen Alfabetik Girin!";
        header('Location: create.php');
        exit();
      }elseif(preg_match('/^[a-zA-Z0-9_]+$/', $name) && $slots < 35){
        $ts3_serv->serverCreate(array(
         "virtualserver_name" => $name,
         "virtualserver_maxclients" => $slots, 
         "virtualserver_port" => $_SESSION['teamspeak']['port'], 
     'virtualserver_hostbanner_url' => 'http://www.izmox.com/',
     'virtualserver_hostbanner_gfx_url' => 'http://izmox.com/ts3.gif',
        ));
        $req = $cnx->prepare("INSERT INTO servers(name, slots, port, username) 
                              VALUES (:name, :slots, :port, :username)");
        $req->execute(array(  
                    'name' => $name, 
                    'slots' => $slots, 
                    'port' => $_SESSION['teamspeak']['port'], 
                    'username' => $_SESSION['auth']['pseudo']
                    ));

        $_SESSION['flash']['success'] = "Sunucu Oluşturuldu !";
        unset($_SESSION['teamspeak']['port']);
        //header('Location: index.php');
        exit();
      }

  }else{
    echo '44';
        $_SESSION['teamspeak']['port'] = rand(2222,7777);
  }

include 'inc/header.php';
?> 
  
  <!DOCTYPE html>
<html lang="en" class="no-js">
    <head>
        <meta charset="UTF-8" />
        <title>Ücretsiz Teamspeak!</title>
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
  </head>
    <body>
        <div class="container">
            <header>
        <h1><span>www.izmox.com</span></h1>
      </header>
            <section>       
                <div id="container_demo" >
                    <div id="wrapper">

        <!-- Main content -->
        <section class="content">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>
          
          <div class="col-md-8">
              <div class="panel panel-default">
                <div class="panel-body">
                   <form action="" method="post"> 
                    <div class="form-group">
                      <center><label for="TS3.Name">Sunucu İsmi</label>
                      <input type="text" name="name" class="form-control" id="TS3.Name" placeholder="Server İsmi @ Powered By LcBilisim.com">
                    </div>
                    <div class="form-group">
                     
            
            
            <center><label for="TS3.Slots">Max Kişi</label>
  <select name="slots" placeholder="100" class="form-control" style="width: 100%;
    height: 50px;
    margin-top: 4px;
    padding: 15px 5px 15px 32px;
    font-size: 13px;
    letter-spacing: 1px;
    border-radius: 5px;
    box-shadow: inset 4px 6px 10px -4px rgba(0, 0, 0, 0.3), 0 1px 1px -1px rgba(255, 255, 255, 0.3);
    background: rgba(0, 0, 0, 0.2);
    outline: none;
    border: 1px solid black;
    margin-bottom: 10px;
    color: #6a9fab;
    text-shadow: #000 0px 1px 5px;
    border-left: 2px solid #3dade9;
    border-right: 2px solid #bf2fcb;
    background-image: -webkit-linear-gradient(left, #3dade9, #bf2fcb), -webkit-linear-gradient(left, #3dade9, #bf2fcb);
    background-image: linear-gradient(left, #3dade9, #bf2fcb), linear-gradient(left, #3dade9, #bf2fcb);
    background-size: 100% 2px;
    background-position: 0 100%, 0 0;
    background-repeat: no-repeat;
    background-clip: border-box;">
                    <option value="5">5</option>
<option value="10">10</option>
<option value="15">15</option>
</select>
                    </div>
                     <div class="form-group">
                      <center><label for="TS3.Port">Port</label>
                      <input type="text" class="form-control" id="TS3.Port" value="<?=$_SESSION['teamspeak']['port']; ?>" disabled>
                    </div>
                 <p class="login button">
         
          <input type="submit" class="btn btn-default" value="Olustur!" />
                  </form>
                </div>
              </div>
        
        <div class="alert-box success"><span>Bilgileri Girdikten Sonra Otomatik Olarak Sizi Yonetim Paneline Aktaricak!</span></div>
        
        <style>
.alert-box {
        color:#555;
        border-radius:10px;
        font-family:Tahoma,Geneva,Arial,sans-serif;font-size:11px;
        padding:10px 36px;
        margin:10px;
    }
    .alert-box span {
        font-weight:bold;
        text-transform:uppercase;
    }
    .error {
        background:#ffecec url('images/error.png') no-repeat 10px 50%;
        border:1px solid #f5aca6;
text-align:center;
    }
    .success {
        background:#e9ffd9 url('images/success.png') no-repeat 10px 50%;
        border:1px solid #a6ca8a;
    }
    .warning {
        background:#fff8c4 url('images/warning.png') no-repeat 10px 50%;
        border:1px solid #f2c779;
    }
    .notice {
        background:#e3f7fc url('images/notice.png') no-repeat 10px 50%;
        border:1px solid #8ed9f6;
    }

</style>


