<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
$idd = $infos->getID($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
$sql_query = "Select * From yedekler WHERE ServerID = ".$idd;
$ts3array = array();
	$sql_query = $cnx->query($sql_query);
	if( $sql_query->rowCount() > 0 ) {
		while($fetch = $sql_query->fetch(PDO::FETCH_ASSOC)) {
        	$ts3array[$fetch['ID']] = $fetch;
        }
    }

$keys = new \App\Keys($ts3_VirtualServer);
$map = $ts3_VirtualServer->getViewer(new TeamSpeak3_Viewer_Html("images/viewer/", "images/countryflags/", "data:image"));

if( isset($_GET['yedek']) ) {
	if( isset($ts3array[$_GET['yedek']]) ) {
		$data = file_get_contents($ts3array[$_GET['yedek']]['YEDEKADI']);

		if($data != '') {
			$sonuc = $ts3_VirtualServer->snapshotDeploy($data);
			echo 'yedek kuruldu';
		}
	}
} elseif( isset($_GET['yedeks']) ) {
	if( isset($ts3array[$_GET['yedeks']]) ) {
		$sql_query = "DELETE From yedekler WHERE ID = ".$_GET['yedeks'];
		if( $cnx->query($sql_query) ) {
			echo 'YEDEK SİLİNDİ';
			unlink($ts3array[$_GET['yedeks']]['YEDEKADI']);
			unset($ts3array[$_GET['yedeks']]);
		}
	}
}
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>
<a href="yedekal.php" class="btn btn-block btn-info">YEDEK AL</a><br/><br/>
<div class="row"><div class="col-lg-12">
<div class="card portlets portlets-inverse">	
<div class="card-header">ALINMIŞ yedekler</div>				
<?php if( count($ts3array) > 0):?>
<table class="table table-hover table-striped">
	<tbody>
	<?php foreach($ts3array as $ts33): ?>
	<tr>
		<td><?=$ts33['YEDEKACIKLAMASI']; ?></td>
		<td><a href="yedekkur.php?yedek=<?=$ts33['ID']?>" class="btn btn-xs btn-success">KUR</a> <a href="yedekkur.php?yedeks=<?=$ts33['ID']?>" onclick="confirm('Bu işlemi yapmak istediğinize emin misiniz?')" class="btn btn-xs btn-danger">SİL</a></td>
	</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<?php else:?>
	<div class="alert alert-success"><strong>HİÇ YEDEĞİNİZ BULUNMAMAKTADIR!</strong></div>
<?php endif; ?>
</div></div></div></div></div></body></html>
