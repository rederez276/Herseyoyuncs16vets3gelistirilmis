<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['kick'])) {
		
		$reason = $_POST['reason'];
		$nick = $_POST['client'];
		
		$ts3_VirtualServer->clientGetByName($nick)->kick(TeamSpeak3::KICK_SERVER, $reason);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="card portlets portlets-info">	
	<div class="card-header">KULLANICI AT</div>				
	<div class="card-block">
							<?php if(isset($_POST['kick'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							
							<?php }else{?>
							<form role="form" method="post" >
								<div class="form-group">
									<center><label>Kullanici Sec</label>
									<select name="client" placeholder="100" class="form-control">
	
										<?php 
											
											foreach($ts3_VirtualServer->clientList() as $tsclient) {
												if($tsclient['client_type'] == 1) continue;
												echo"<option value=$tsclient>".$tsclient."</option>";
											}
										?>
									</select>
								</div>
								<div class="form-group">
									<center><label>Kickleme Nedeni</label></center>
									<input type="text" class="form-control" name="reason" placeholder="Nedeni">
								</div>
						
								<div class="box-footer">
									
									
									<center><input type="submit" name="kick" class="btn btn-info" value="Kickle!" />
								</div>
							</form>
							<?php } ?>
						</div>
					</div>
					
					
				</div>
		</div>
		</center>
		</center>
		</div>
		</label<select>
		</center>
		</div>
		</form>
		</b>
		</div>
		</div>
		</div></div>
		
	</div>
	</div>
	</body>
	</html>
	

										

					  