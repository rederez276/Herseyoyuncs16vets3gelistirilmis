<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
$idd = $infos->getID($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);

$keys = new \App\Keys($ts3_VirtualServer);
	try {	
		$permList = $ts3_VirtualServer->serverGroupList();
		$tokenList = $ts3_VirtualServer->privilegeKeyList(true);
	} catch( Exception $e ) {
		$tokenList = array();
	}

	if( isset($_GET['kaldirID']) ) {
		$_SESSION['flash']['success'] = "Token Kaldırıldı (TokenID: ".$_GET['kaldirID'].")";
		$ts3_VirtualServer->privilegeKeyDelete($_GET['kaldirID']);
		header('Location: tokenlist.php');
		exit();
	} elseif( isset($_POST['permidd']) ) {
		if( $_POST['permidd'] > 0 ) {
			$var = false;
			foreach($permList as $permm): 
				if($permm['type'] == 1 && $permm['sgid'] == (int)$_POST['permidd']) {
					$var = true;
					break;
				}
			endforeach;
			if( $var ) {
				$arr_ServerGroup = $ts3_VirtualServer->serverGroupGetById((int)$_POST['permidd']);
				$ts3_PrivilegeKey = $arr_ServerGroup->privilegeKeyCreate();
				$_SESSION['flash']['success'] = "Token Oluşturuldu! (TOKEN: ".$ts3_PrivilegeKey.")";
				header('Location: tokenlist.php');
				exit();
			} else {
				$_SESSION['flash']['danger'] = "Token Oluşturulamadı!";
				header('Location: tokenlist.php');
				exit();
			}
		}
	}
}
catch (Exception $e)
{
  
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  //header('Location: offline.php');
  exit();
}

?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>

<div class="row"><div class="col-lg-12">
<div class="card portlets portlets-success">	
<div class="card-header">Token Oluştur</div>				
<div class="card-block">
		<form action="tokenlist.php" method="POST">
		<div class="col-lg-12 form-group">
			<select name="permidd" class="form-control">
				<option value="-">Belirsiz</option>
				<?php foreach($permList as $permm): if($permm['type'] != 1) continue; ?>
				<option value="<?=$permm['sgid']?>"><?php echo '(ID '.$permm['sgid'].') '.$permm['name']; ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="col-lg-12 form-group"><button class="btn btn-success btn-block" style="color:white;">TOKEN OLUŞTUR</button></div>
		</form>
</div>
</div>
</div>
</div>
<div class="row"><div class="col-lg-12">
<div class="card portlets portlets-info">	
<div class="card-header">Token Listesi</div>				
<table class="table table-striped table-hover">
	<thead>
	<tr>
		<th>Token</th>
		<th>Tip</th>
		<th>Yetki 1</th>
		<th>Yetki 2</th>
		<th>Tarih</th>
		<th>Açıklama</th>
		<th>İşlemler</th>
	</tr>
	</thead>
	<tbody>
	<?php if(count($tokenList) > 0): foreach($tokenList as $tokenn): ?>
	<tr>
		<td><?php echo $tokenn['token']; ?></td>
		<td><?php echo $tokenn['token_type'] ? 'Channel (Kanal)' : 'Server' ?></td>
		<td><?php echo $tokenn['token_id1'] ? $tokenn['token_id1'] : '-' ?></td>
		<td><?php echo $tokenn['token_id2'] ? $tokenn['token_id2'] : '-' ?></td>
		<td><?php echo date('d.m.Y - H:i:s', $tokenn['token_created']); ?></td>
		<td><?php echo $tokenn['token_description'] ?></td>
		<td><a href="tokenlist.php?kaldirID=<?php echo str_replace('+','%2B',$tokenn['token']); ?>" class="btn btn-xs btn-danger">KALDIR</a></td>
	</tr>
	<?php endforeach; else: ?>
	<tr>
		<td colspan="7" style="text-align:center;">Token Listesi tertemiz!</td>
	</tr>
	<?php endif; ?>
	</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>