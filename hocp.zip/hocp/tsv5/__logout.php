<?php
session_start();
setcookie('remember', NULL, -1);
unset($_SESSION['auth']);
$_SESSION['flash']['success'] = 'www.izmox.com - Basariyla Cikis Yapildi!';
header('Location: login.php');