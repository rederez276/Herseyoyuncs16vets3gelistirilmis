<?php
require_once(__DIR__.'/../../sistem/ayarlar.php');
try
{
    $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

    // Yeni değişkenler ile bağlantı kur
    $cnx = new PDO(
        'mysql:host=' . $oGCP['veritabani']['host'] . ';dbname=' . $oGCP['veritabani']['vtadi'],
        $oGCP['veritabani']['kadi'],
        $oGCP['veritabani']['sifre'],
        $pdo_options
    );
}
catch (Exception $e)
{
    die('Error: ' . $e->getMessage());
}
?>
