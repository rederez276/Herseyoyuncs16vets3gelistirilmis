﻿<?php
// load framework files

require_once("libraries/TeamSpeak3/TeamSpeak3.php");



/* connect to server, authenticate and get TeamSpeak3_Node_Server object by URI */
///$ts3_serv = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/");
