$(document).ready(function() {
//waves effect js start
 Waves.init();
    Waves.attach('.flat-buttons', ['waves-button']);
    Waves.attach('.float-buttons', ['waves-button', 'waves-float']);
    Waves.attach('.float-button-light', ['waves-button', 'waves-float', 'waves-light']);
    Waves.attach('.flat-buttons',['waves-button', 'waves-float', 'waves-light','flat-buttons']);
//waves effect js end
});
