<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$usrname:$pass@$host:$qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);


$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$usrname:$pass@$host:$qport/?server_port=".$port);


 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]╔══════════════════════╗",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 




 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]٠•●۞ www.izmox.com - уöηєтιм σ∂αѕı ۞●•٠",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]╚══════════════════════╝",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer89561989498cccccc8ca82221344]___",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]www.izmox.com - Hosgeldiniz",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "╔═════════════════════════════╗",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - уσηєтιм єкιвιмιz",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - кυяαℓℓαяıмız",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - dυyυrυlαr",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - вιℓgιℓєη∂ιямє",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - тσρℓαηтı σ∂αѕı",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - ιℓєтιѕιм",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - вαɴ lιѕтeѕι",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - тєαмѕρєαк Э тüякçє уαρмα",
  "channel_topic"          => "",
  "channel_description"          => " ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "║•●۞ www.izmox.com - Ip αdreѕιмιz",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "╚═════════════════════════════╝",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer89561989498cccccc882221344]___",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer8]↓",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer9]Ðєѕтєк – Kαyıт Yαpтırмα",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer9]Ðeѕтeĸ – Odα Açтırмα",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer10]Ðєѕтєк – Öηєяι̇ Şι̇кαуєт",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer12]↑",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacerxw13]___",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]╔────╬╬╬─────────╬╬╬───╗",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer] •●۞ H σ ş g є ℓ ∂ i η i z ۞●•",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
    "CHANNEL_NEEDED_TALK_POWER" => "100",


)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]╚────╬╬╬─────────╬╬╬───╝",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacerwxx13]___",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer7]╔══════════════════════╗",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]ѕσнвєт σ∂αѕı",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer4]╠══════════════════════╣",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]♫♫ мüzιк σ∂αѕı ♫♫",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer9]╚══════════════════════╝",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacerwxc13]___",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer36]▄",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer37]▬▬▬▬▬▬▬▬▬๑۩۞۩๑▬▬▬▬▬▬▬▬▬",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]► ☆ KLAN ADI ☆ ◄",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer]► ☆ Kℓαηα Aℓıм Şαятℓαяı ☆ ◄",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[cspacer39]▬▬▬▬▬▬▬▬๑۩۞۩๑▬▬▬▬▬▬▬▬",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
 
 
 
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer40]▄",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
  
  
  



 $top_cid = $ts3_VirtualServer->channelCreate(array(
  "channel_name"           => "[*spacer1301]●—",
  "channel_topic"          => "",
  "channel_description"          => "  ",
  "channel_codec"          => TeamSpeak3::CODEC_SPEEX_WIDEBAND,
  "channel_flag_permanent" => TRUE,
)); 
 
 
  
  
  

 echo'Odalar Oluşturuldu';
 
 header('Location: index.php');
  exit();

?>