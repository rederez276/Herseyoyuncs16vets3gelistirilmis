<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}
try {
$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['kick'])) {
		
		$reason = $_POST['reason'];
		$nick = $_POST['client'];
		$time = (int)$_POST['time'];
		
		$ts3_VirtualServer->clientGetByName($nick)->ban($timeseconds = $time,$reason = $reason);
	}
} catch( Exception $e ) {
	$_SESSION['flash']['danger'] = "Bu yetkideki kişi banlanamaz!";
	  header('Location: ban.php');
	  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>CSBizde Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            		<?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); endif; ?>
		<div class="row">
			<div class="col-md-12">
				
					
					<div class="card portlets portlets-info">	
<div class="card-header">
					KULLANICI YASAKLA
				</div>				
<div class="card-block">
							<?php if(isset($_POST['kick'])) { 
								
								$razon = $_POST['reason'];
								$nick = $_POST['client'];
								$time = $_POST['time'];
								if($time == 0){$timefinal = "Permanent";} else{$timefinal = $time;}
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							
							<?php }else{?>
							<form role="form" method="post" >
								<div class="form-group">
									<center><label>Kullanici Sec.</label>
									<select name="client" placeholder="100" class="form-control">
	
										<?php 
											
											foreach($ts3_VirtualServer->clientList() as $tsclient) {
												if($tsclient['client_type'] == 1) continue;
												echo"<option value=$tsclient>".$tsclient."</option>";
											}
										?>
									</select>
								</div>
								<div class="form-group">
									<center><label>Banlama Nedeni.</label></center>
									<input type="text" class="form-control" name="reason" placeholder="Nedeni">
								</div>
								<div class="form-group">
									<center><label>Banlama Süresi.</label></center>
									<input type="text" class="form-control" name="time" placeholder="0 Yazarsaniz Kalici Banlar.">
								</div>
								<div class="box-footer">
									
									
									<center><input type="submit" name="kick" class="btn btn-success" value="Banla!" />
								</div>
							</form>
							<?php } ?>
						</div>
					</div>
					
					
				</div>
		</div>
		</section>
		
	</div>
	</center>
	</center>
	</div>
	</center></div>
	</form>
	</b>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</body>
	</html>

										

					  