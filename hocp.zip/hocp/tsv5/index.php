<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);
$map = $ts3_VirtualServer->getViewer(new TeamSpeak3_Viewer_Html("images/viewer/", "images/countryflags/", "data:image"));

  if(isset($_GET) && !empty($_GET['key'])){
    $keys->generate($_GET['key']);
  }

try {
	if( isset($_POST['ayar_kaydet'],$_POST['virtualserver_name'],$_POST['virtualserver_hostmessage'],$_POST['virtualserver_welcomemessage'],$_POST['virtualserver_hostbanner_url'],$_POST['virtualserver_hostbanner_gfx_url']) ) {
		$ts3_VirtualServer->virtualserver_name = $_POST['virtualserver_name'];
		$ts3_VirtualServer->virtualserver_hostmessage = $_POST['virtualserver_hostmessage'];
		$ts3_VirtualServer->virtualserver_welcomemessage = $_POST['virtualserver_welcomemessage'];
		$ts3_VirtualServer->virtualserver_hostbanner_url = $_POST['virtualserver_hostbanner_url'];
		$ts3_VirtualServer->virtualserver_hostbanner_gfx_url = $_POST['virtualserver_hostbanner_gfx_url'];
		$_SESSION['flash']['success'] = "Kayıt Başarılı!";
		header('Location: index.php');
		exit();
	}
} catch( Exception $e ) {
	$_SESSION['flash']['danger'] = "Kayıt Başarısız!";
	header('Location: index.php');
	exit();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>
<div class="row"><div class="col-md-6 col-xs-12">
<div class="card portlets portlets-danger">	
<div class="card-header text-uppercase">www.izmox.com - ANLIK SUNUCU BİLGİLERİ</div>				
<table class="table table-striped table-hover">
	<tbody>
	<tr>
		<td>Sunucu İsmi</td>
		<td><?= $server_status = $ts3_VirtualServer->virtualserver_name ?></td>
	</tr>
	<tr>
		<td>Sunucu IP</td>
		<td><?=$ts_host.':'.$port?></td>
	</tr>
	<tr>
		<td>Anlık İndirme</td>
		<td><?=  $server_status = $ts3_VirtualServer->connection_bytes_received_total ?></td>
	</tr>
	<tr>
		<td>Anlık Yükleme</td>
		<td><?=  $server_status = $ts3_VirtualServer->connection_bytes_sent_total ?></td>
	</tr>
	<tr>
		<td>Max Slot</td>
		<td><?=  $server_status = $ts3_VirtualServer->virtualserver_maxclients ?></td>
	</tr>
	<tr>
		<td>Kanal Sayısı</td>
		<td><?= $server_status = $ts3_VirtualServer->virtualserver_channelsonline ?></td>
	</tr>
	<tr>
		<td>Sunucu Durumu</td>
		<td><?= $server_status = $ts3_VirtualServer->virtualserver_status ?></td>
	</tr>
	<tr>
		<td>Anlık Online</td>
		<td><?= $server_status = $server_actuallyusers = $ts3_VirtualServer->virtualserver_clientsonline - $ts3_VirtualServer->virtualserver_queryclientsonline; ?></td>
	</tr>
	</tbody>
</table>
</div>
</div>


<div class="col-md-6 col-xs-12">
<div class="card portlets portlets-primary">	
<div class="card-header">SUNUCU AYARLARI</div>
<form action="index.php" method="POST">		
<div class="card-block">
	<div class="row">
		<div class="col-md-6 form-group">Sunucu İsmi</div>
		<div class="col-md-6 form-group"><input class="form-control" type="text" name="virtualserver_name" value="<?= $server_status = $ts3_VirtualServer->virtualserver_name ?>" ></div>
	</div>
	<div class="row">
		<div class="col-md-6 form-group">Host Mesajı</div>
		<div class="col-md-6 form-group"><input class="form-control" type="text" name="virtualserver_hostmessage" value="<?= $server_status = $ts3_VirtualServer->virtualserver_hostmessage ?>" ></div>
	</div>
	<div class="row">
		<div class="col-md-6 form-group">Hoşgeldin Mesajı</div>
		<div class="col-md-6 form-group"><input class="form-control" type="text" name="virtualserver_welcomemessage" value="<?= $server_status = $ts3_VirtualServer->virtualserver_welcomemessage ?>" ></div>
	</div>
	<div class="row">
		<div class="col-md-6 form-group">Banner Link</div>
		<div class="col-md-6 form-group"><input class="form-control" type="text" name="virtualserver_hostbanner_url" value="<?= $server_status = $ts3_VirtualServer->virtualserver_hostbanner_url ?>" ></div>
	</div>
	<div class="row">
		<div class="col-md-6 form-group">Banner Resim Link</div>
		<div class="col-md-6 form-group"><input class="form-control" type="text" name="virtualserver_hostbanner_gfx_url" value="<?= $server_status = $ts3_VirtualServer->virtualserver_hostbanner_gfx_url ?>" ></div>
	</div>
	<div class="row">
		<div class="col-md-12 form-group">
			<button class="btn btn-block btn-primary" type="submit" name="ayar_kaydet">Kaydet</button>
		</div>
	</div>
</div></form>
</div>
</div>
</div>
</div>
<p>Gametracker</p><span></span>
<div class="block-content" style="padding:0">
  <table class="table">
    <tr>
      <td>Sunucu IP</td>
      <td><?=$ts_host.':'.$port?></td>
    </tr>
    <tr>
      <td>
        <a href="https://www.gametracker.com/server_info/<?=@$ts_host?>:<?=$port?>/" target="_blank">
          <img src="https://cache.gametracker.com/server_info/<?=@$ts_host?>:<?=$port?>/b_350_20_692108_381007_ffffff_000000.png" border="0" width="350" height="20" alt=""/>
        </a>    
      </td>
      <td>
        <img src="https://cache.gametracker.com/server_info/<?=@$ts_host?>:<?=$port?>/b_560_95_1.png" alt="Gametracker Image" />
      </td>
    </tr>
  </table>
</div>
</body>
</html>