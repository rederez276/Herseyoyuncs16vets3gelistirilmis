<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['kick'])) {
		
		$reason = $_POST['reason'];
		$nick = $_POST['client'];
		
		$ts3_VirtualServer->clientGetByName($nick)->kick(TeamSpeak3::KICK_SERVER, $reason);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Görüntüke</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">


<center><br><br><?php echo $ts3_VirtualServer->getViewer(new TeamSpeak3_Viewer_Html("images2/viewericons/", "images2/countryflags/", "data:image")); ?></br></br></center>



					
					
				</div>
		</div>
		</center>
		</center>
		</div>
		</label<select>
		</center>
		</div>
		</form>
		</b>
		</div>
		</div>
		</div></div>
		
	</div>
	</div>
	</body>
	</html>
	

										

					  