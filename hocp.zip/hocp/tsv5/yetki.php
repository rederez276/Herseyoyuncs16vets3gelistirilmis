<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['yetkiver'])) {
		
		
		$nick = $_POST['client'];
		$sgid = "2";     //BURAYA IM'BOT IDSİ YAZILICAK.
$cldbid = "3";   // a friends clientBDid

		 $ts3_VirtualServer->serverGroupClientAdd($sgid, $nick);
	}
	
		if(isset($_POST['yetkial'])) {
		
		
		$nick = $_POST['client'];
		$sgid = "2";     //BURAYA IM'BOT IDSİ YAZILICAK.
$cldbid = "3";   // a friends clientBDid

		 $ts3_VirtualServer->serverGroupClientDel($sgid, $nick);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="card portlets portlets-info">	
	<div class="card-header">I'M BOT YÖNETİMİ</div>				
	<div class="card-block">
							<?php if(isset($_POST['yetkiver'])) { 
								
								
							?>	
							<div class="alert alert-success"><b></div>
							<meta http-equiv="refresh" content="3" >
							
							
							<?php }else{?>
							<form role="form" method="post" >
								<div class="form-group">
									<center><label>Kullanici Sec</label>
									<select name="client" placeholder="100" class="form-control">
	
													<?php 
											foreach($ts3_VirtualServer->clientList() as $tsclient) {
 
												if($tsclient['client_type'] == 1) continue;
												$diq = $tsclient['client_database_id'];
												echo"<option value=$diq>".$tsclient."</option>";
 
                                                                                        }
                                                                                        if(!$diq){
                                                                                        echo '<option disabled selected>Kullanıcı Bulunamadı</option>';
                                                                                        }
										?>	
									</select>
								</div>
						
						
									
								<?php
if($diq){
echo '<input type="submit" name="yetkiver" value="Yetki Ver" class="btn btn-success"> &nbsp;';
echo '<input type="submit" name="yetkial" value="Yetki Al" class="btn btn-danger">';
}else{
echo '<input type="button" value="Henüz Kullanıcı Yok" class="btn btn-danger">';
}
?>
								</div>
							</form>
							<?php } ?>
						</div>
					</div>
					
					
				</div>
		</div>
		</center>
		</center>
		</div>
		</label<select>
		</center>
		</div>
		</form>
		</b>
		</div>
		</div>
		</div></div>
		
	</div>
	</div>
	</body>
	</html>
	

										

					  