<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}

$keys = new \App\Keys($ts3_VirtualServer);

	
	if(isset($_POST['kick'])) {
		
		$reason = $_POST['reason'];
		$nick = $_POST['client'];
		
		$ts3_VirtualServer->clientGetByName($nick)->kick(TeamSpeak3::KICK_SERVER, $reason);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Eklentiler</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">


				
<div class="panel panel-default">

  <div class="panel-heading">Eklenti Yönetimi</div>

<div class="panel panel-default">


  <div class="panel-body">

							






<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">+5 Oda Oluştur</h4>
      </div>
      <div class="modal-body">
	  
	  
	  
<form action="?sayfa=oda" method="post" >

  <label for="usr">CLAN ADI:</label>
  <input type="text" name="oda" class="form-control" >
</div>
<input type="submit" class="btn btn-primary btn-block" value="ODALARI AÇ" name="odac">
</form>		
      </div>
      </div>
      </div>
    </div>

  </div>



<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Oda Oluştur</h4>
      </div>
      <div class="modal-body">
	  
	  
	  
<form action="?sayfa=createchannel" method="post" >

  <label for="usr">ODA ADI:</label>
  <input type="text" name="oda" class="form-control" >
</div>
<input type="submit" class="btn btn-primary btn-block" value="ODALARI AÇ" name="odac">
</form>		
      </div>
      </div>
      </div>
  
















	
<div class="col-lg-6">
<div class="panel panel-success">
<div class="panel-body">
<center>

</form>
</form>
</center>
</div>
</div>
</div>
	
<div class="col-lg-6">
<div class="panel panel-success">

</form>
</center>
</div>
</div>
</div>

<div class="col-lg-6">
<div class="panel panel-success">
<div class="panel-heading"><b><center>HIZLI</center></b></div>
<div class="panel-body">


<a href="?sayfa=banlistesi" class="btn btn-danger btn-block" >BAN LISTESI</a>  
<button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#myModal">+5 Oda Aç</button>
<a href="?sayfa=log" class="btn btn-success btn-block" >TS3 SON 100 LOG</a>

</div>
</div>














													</div>
					</div>
					
				</div>
		</div>
		
	</div>














</div>
													</div>
					</div>
					
				</div>
		</div>
		
	</div>




					
					
				</div>
		</div>
		</center>
		</center>
		</div>
		</label<select>
		</center>
		</div>
		</form>
		</b>
		</div>
		</div>
		</div></div>
		
	</div>
	</div>
	</body>
	</html>
	

										

					  