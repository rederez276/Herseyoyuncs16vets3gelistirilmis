<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
if(!isset($_SESSION['flash']['danger'])){
  header('Location: index.php');
  exit();
}
?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>www.izmox.com - Teamspeak3 Arayüzü</title>
        
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
  </head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>
        
		                <br> <center><a href='ac.php'><input type='button' class="btn btn-success btn-block" value="Sunucuyu Aç"></a><br/><br/><a href='kapat.php'><input type='button' class="btn btn-warning btn-block" value="Sunucuyu Kapat"></a>
</center>
</center>
</div>
</div>
</body>
</html>



       
