<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);

$datayedek = $ts3_VirtualServer->snapshotCreate();
if( $datayedek != FALSE) {
	file_put_contents('yedekler/yedek_'.str_replace('.','',$ts_host).'_'.$port.'_'.time().'.snapshot', $datayedek);
	$sql_query = "INSERT INTO yedekler(ServerID,YEDEKADI,YEDEKACIKLAMASI) VALUES (".$infos->getID($_SESSION['auth']['pseudo']).", '".('yedekler/yedek_'.str_replace('.','',$ts_host).'_'.$port.'_'.time().'.snapshot')."', 'YEDEK (".date('d.m.Y - H:i:s').") ALINDI')";
	$cnx->query($sql_query);
  $_SESSION['flash']['danger'] = "YEDEK BAŞARIYLA ALINDI!";
  header('Location: yedekkur.php');
  exit();
}

}
catch (Exception $e)
{
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  header('Location: offline.php');
  exit();
}
?>