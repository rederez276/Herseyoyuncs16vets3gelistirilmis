<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';
if(!isset($_SESSION['auth'])){
  header('Location: login.php');
  exit();
}
$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);
$idd = $infos->getID($_SESSION['auth']['pseudo']);
try
{
/* 
  CHANGE THIS LINE WITH YOUR TS3 QUERY INFOS
*/

$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);

$keys = new \App\Keys($ts3_VirtualServer);
	try {
		$banlist = $ts3_VirtualServer->banList();
	} catch( Exception $e ) {
		$banlist = array();
	}

	if( isset($_GET['kaldirID']) ) {
		if( is_numeric($_GET['kaldirID']) ) {
			if( $_GET['kaldirID'] == 0 ) {
				$ts3_VirtualServer->banListClear();
				$_SESSION['flash']['success'] = "Tüm Banlar Temizlendi";
				header('Location: banlist.php');
			} else {
				$_SESSION['flash']['success'] = "Ban Kaldırıldı (BANID: ".$_GET['kaldirID'].")";
				$ts3_VirtualServer->banDelete($_GET['kaldirID']);
				header('Location: banlist.php');
			}
		}
	}
}
catch (Exception $e)
{
  
  $_SESSION['flash']['danger'] = "Sunucu Kapalidir Lütfen Aciniz";
  $offline = true;
  //header('Location: offline.php');
  exit();
}

?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>CSBizde Teamspeak3 Arayüzü</title>
       	
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
	</head>
    <body style="background: transparent !important;">
    <div class="wrapper">
              <!-- Main content starts -->
                    <div class="container-fluid">
            <?php if(isset($_SESSION['flash'])): ?>
              <?php foreach($_SESSION['flash'] as $type => $message): ?>
                  <div class="alert alert-<?= $type; ?>">
                      <?= $message; ?>
                  </div>
              <?php endforeach; ?>
              <?php unset($_SESSION['flash']); ?>
          <?php endif; ?>
<a href="banlist.php?kaldirID=0" class="btn btn-warning btn-block" style="color:white;">TÜM BANLARI KALDIR</a><br/><br/>
<div class="row"><div class="col-lg-12">
<div class="card portlets portlets-danger">	
<div class="card-header text-uppercase">Yasaklı Listesi</div>				
<table class="table table-striped table-hover">
	<thead>
	<tr>
		<th>IP / Nick</th>
		<th>Neden</th>
		<th>Tarih</th>
		<th>Süre</th>
		<th>Banı Atan</th>
		<th>İşlemler</th>
	</tr>
	</thead>
	<tbody>
	<?php if(count($banlist) > 0): foreach($banlist as $bann): ?>
	<tr>
		<td><?php echo $bann["uid"] != "" ? ($bann['lastnickname'].' ('.$bann['uid'].')') : ($bann['ip']) ?></td>
		<td><?php echo $bann['reason'] ?></td>
		<td><?php echo date('d.m.Y - H:i:s',$bann['created']); ?></td>
		<td><?php echo $bann['duration'] ?> saniye</td>
		<td><?php echo '('.$bann['invokercldbid'].') '.$bann['invokeruid'] ?></td>
		<td><a href="banlist.php?kaldirID=<?php echo $bann['banid']; ?>" class="btn btn-xs btn-warning">KALDIR</a></td>
	</tr>
	<?php endforeach; else: ?>
	<tr>
		<td colspan="6" style="text-align:center;">Ban Listesi tertemiz!</td>
	</tr>
	<?php endif; ?>
	</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>