<?php 
session_start();
include 'inc/header.php';
require_once("libraries/TeamSpeak3/TeamSpeak3.php");
require 'app/Verify.php';
require 'app/Infos.php';
require 'app/Keys.php';
require 'inc/db.php';
require 'inc/ts.php';

$verify = new \App\Verify($cnx);
$verify->checkIndex($_SESSION['auth']['pseudo']);
$infos = new \App\Infos($cnx);
$port = $infos->getPort($_SESSION['auth']['pseudo']);

/* connect to server, authenticate and get TeamSpeak3_Node_Server object by URI */
$ts3_VirtualServer = TeamSpeak3::factory("serverquery://$ts_usrname:$ts_pass@$ts_host:$ts_qport/?server_port=".$port);
$ts3_VirtualServer->stop();
$ts3_VirtualServer->start();

header('Location: index.php');
  exit();

